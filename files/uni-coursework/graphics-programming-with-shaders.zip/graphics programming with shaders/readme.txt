Rachel Crawford, 1204444@abertay.ac.uk
Graphics Programming With Shaders (AG0904A) Coursework Project

Press the buttons 1, 2, 3 to switch between different demos/scenes.

1. Voxel Space Demo
	- compute shader, render-to-texture
	- controls:
		- arrows - camera forward, backwards, turn left/right
		- A - camera up
		- B - camera down
		- PgUp - camera rotate up
		- PgDn - camera rotate down

2. Water Demo
	- directional lighting
	- cube-mapped sky and reflection of sky on water surface
	- render-to-texture, post-processing (pixelation)
	- vertex position & normal manipulation: waves & normal-mapping
	- tessellation
	- controls:
		- camera controls same as in voxel space demo
		- , (comma) and . (full stop) - decrease/increase amplitude of all waves
		- + and - increase/decrease tessellation
		- P - toggle pixelation effect
		- [] - modify pixelation amount

3. Particle Effect Demo
	- geometry shader - point-sprite expansion
	- sort of gave up on this when I realised I couldn't do depth-sorting
	- controls:
		- camera controls same again