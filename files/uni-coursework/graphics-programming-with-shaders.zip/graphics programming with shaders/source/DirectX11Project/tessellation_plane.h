// Rachel Crawford (1204444@abertay.ac.uk) 2014

#ifndef TESSELLATION_PLANECLASS_H_
#define TESSELLATION_PLANECLASS_H_

#include <d3d11.h>
#include <d3dx10math.h>
#include <math.h>
#include "meshclass.h"

class TessellationPlane : public MeshClass
{
public:
	TessellationPlane();
	TessellationPlane(const TessellationPlane&);
	virtual ~TessellationPlane();

	bool Initialize(ID3D11Device*, WCHAR*);

private:
	bool InitializeBuffers(ID3D11Device*);

	int m_planeWidth;
	int m_planeHeight;

};

#endif // TESSELLATION_PLANECLASS_H_