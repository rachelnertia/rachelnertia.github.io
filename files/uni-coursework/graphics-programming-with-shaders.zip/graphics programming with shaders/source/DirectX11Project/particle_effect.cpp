#include "particle_effect.h"

#include "helpers.h"



bool ParticleEffect::Initialize(ID3D11Device* device, HWND hwnd) {
	// Create the geometry shader
	if (!CreateShaderObject(device, hwnd, L"particle_gs.hlsl", "main",
		(ID3D11DeviceChild**)&m_geometry_shader, ST_GEOMETRY)) {
		return false;
	}
	
	// Create the pixel shader
	if (!CreateShaderObject(device, hwnd, L"particle_ps.hlsl", "main",
		(ID3D11DeviceChild**)&m_pixel_shader, ST_PIXEL)) {
		return false;
	}
	// Create the vertex shader
	if (!CreateShaderObject(device, hwnd, L"particle_vs.hlsl", "main",
		(ID3D11DeviceChild**)&m_vertex_shader, ST_VERTEX)) {
		return false;
	}

	if (!CreateMatrixBuffer(device)) {
		return false;
	}

	if (!CreateSampler(device)) {
		return false;
	}

	if (!CreateBlender(device)) {
		return false;
	}

	return true;
}



bool ParticleEffect::Shutdown() {
	SafeRelease(&m_geometry_shader);

	return Effect::Shutdown();
}



bool ParticleEffect::Render(ID3D11DeviceContext* context, int vertex_count,
	ID3D11ShaderResourceView* texture_srv,
	D3DXMATRIX world_matrix, D3DXMATRIX view_matrix,
	D3DXMATRIX projection_matrix) {
	// Send the matrices to the GEOMETRY shader
	{
		// Transpose the matrices to prepare them for the shader.
		D3DXMatrixTranspose(&world_matrix, &world_matrix);
		D3DXMatrixTranspose(&view_matrix, &view_matrix);
		D3DXMatrixTranspose(&projection_matrix, &projection_matrix);

		D3D11_MAPPED_SUBRESOURCE mapped_resource;

		// Lock the constant buffer so it can be written to.
		HRESULT result = context->Map(m_matrix_buffer, 0,
			D3D11_MAP_WRITE_DISCARD, 0, &mapped_resource);
		if (FAILED(result))	{
			return false;
		}

		// Get a pointer to the data in the constant buffer.
		MatrixBuffer* matrix_buffer = (MatrixBuffer*)mapped_resource.pData;

		// Copy the matrices into the constant buffer.
		matrix_buffer->world = world_matrix;
		matrix_buffer->view = view_matrix;
		matrix_buffer->projection = projection_matrix;

		// Unlock the constant buffer.
		context->Unmap(m_matrix_buffer, 0);

		// Now set the constant buffer in the vertex shader with the updated 
		// values.
		context->GSSetConstantBuffers(0, 1, &m_matrix_buffer);
	}


	// Set the texture to use in the pixel shader
	context->PSSetShaderResources(0, 1, &texture_srv);

	// Set the vertex input layout.
	context->IASetInputLayout(m_layout);

	// Set the shaders that will be used to render this triangle.
	context->VSSetShader(m_vertex_shader, NULL, 0);
	context->PSSetShader(m_pixel_shader, NULL, 0);
	context->GSSetShader(m_geometry_shader, NULL, 0);

	// Set the sampler state in the pixel shader.
	context->PSSetSamplers(0, 1, &m_sampler_state);

	// Set the blend state in the pixel shader
	context->OMSetBlendState(m_blend_state, 0, 0xffffffff);

	// Render the POINT.
	// TODO: Try doing this with just Draw, so there's no need to lug a index array around.
	//context->DrawIndexed(index_count, 0, 0);
	context->Draw(vertex_count, 0);

	// Clean up.
	{
		// ... shaders
		context->PSSetShader(NULL, NULL, 0);
		context->VSSetShader(NULL, NULL, 0);
		context->GSSetShader(NULL, NULL, 0);
		// ... texture
		ID3D11ShaderResourceView* ppSRVNULL[1] = { NULL };
		context->PSSetShaderResources(0, 1, ppSRVNULL);
	}

	return true;
}



// Override of Effect::CreateVertexShaderInputLayout
/*
	This effect requires only that a point be passed to the vertex shader, so this
	override doesn't bother making space for the texture coordinate or normal.
*/
bool ParticleEffect::CreateVertexShaderInputLayout(ID3D11Device* device,
	ID3D10Blob* vs_bytecode) {
	D3D11_INPUT_ELEMENT_DESC polygonLayout[1];
	unsigned int numElements;

	// Create the vertex input layout description.
	// This setup needs to match the VertexType stucture in the MeshClass and
	// in the shader.
	polygonLayout[0].SemanticName = "POSITION";
	polygonLayout[0].SemanticIndex = 0;
	polygonLayout[0].Format = DXGI_FORMAT_R32G32B32_FLOAT;
	polygonLayout[0].InputSlot = 0;
	polygonLayout[0].AlignedByteOffset = 0;
	polygonLayout[0].InputSlotClass = D3D11_INPUT_PER_VERTEX_DATA;
	polygonLayout[0].InstanceDataStepRate = 0;

	// Get a count of the elements in the layout.
	numElements = sizeof(polygonLayout) / sizeof(polygonLayout[0]);

	// Create the vertex input layout.
	HRESULT result = device->CreateInputLayout(polygonLayout, numElements,
		vs_bytecode->GetBufferPointer(),
		vs_bytecode->GetBufferSize(), &m_layout);
	if (FAILED(result))
	{
		return false;
	}

	return true;
}


bool ParticleEffect::CreateBlender(ID3D11Device* device) {
	D3D11_BLEND_DESC blendDesc;
	ZeroMemory(&blendDesc, sizeof(D3D11_BLEND_DESC));
	blendDesc.AlphaToCoverageEnable = false;
	blendDesc.IndependentBlendEnable = true;
	blendDesc.RenderTarget[0].BlendEnable = true;
	blendDesc.RenderTarget[0].SrcBlend = D3D11_BLEND_SRC_ALPHA;
	blendDesc.RenderTarget[0].DestBlend = D3D11_BLEND_ONE;
	blendDesc.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
	blendDesc.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ZERO;
	blendDesc.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_ZERO;
	blendDesc.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;
	blendDesc.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
	//create the blender state
	HRESULT result = device->CreateBlendState(&blendDesc, &m_blend_state);
	if (FAILED(result))
	{
		return false;
	}

	return true;
}