#ifndef _VMSHADERCLASS_H_
#define _VMSHADERCLASS_H_

#include <d3d11.h>
#include <d3dx10math.h>
#include <d3dx11async.h>
#include <fstream>
using namespace std;
#include <time.h>
#include "lightclass.h"

// Vertex Manipulation Shader class
class VMShaderClass
{
public:
	VMShaderClass();
	VMShaderClass(const VMShaderClass&);
	~VMShaderClass();

	bool Initialize(ID3D11Device*, HWND);
	void Shutdown();
	bool Render(ID3D11DeviceContext*, int, D3DXMATRIX, D3DXMATRIX, D3DXMATRIX, 
		ID3D11ShaderResourceView*, LightClass*, float time);

	float GetHeight() const
	{
		return m_height;
	}
	void SetHeight(const float height)
	{
		m_height = height;
	}
	float GetWidth() const
	{
		return m_width;
	}
	void SetWidth(const float width)
	{
		m_width = width;
	}

private:
	bool InitializeShader(ID3D11Device*, HWND, WCHAR*, WCHAR*);
	void ShutdownShader();
	void OutputShaderErrorMessage(ID3D10Blob*, HWND, WCHAR*);

	bool SetShaderParameters(ID3D11DeviceContext*, D3DXMATRIX, D3DXMATRIX, D3DXMATRIX, 
		ID3D11ShaderResourceView*, LightClass*, float time);
	void RenderShader(ID3D11DeviceContext*, int);


	ID3D11VertexShader* m_vertexShader;
	ID3D11PixelShader* m_pixelShader;
	ID3D11InputLayout* m_layout;
	ID3D11SamplerState* m_sampleState;
	ID3D11Buffer* m_matrixBuffer;

	ID3D11Buffer* m_lightBuffer;
	ID3D11Buffer* m_timeBuffer;

	float m_height;
	float m_width;

	time_t timer;
	float elapsedTime;

	struct MatrixBufferType
	{
		D3DXMATRIX world;
		D3DXMATRIX view;
		D3DXMATRIX projection;
	};

	struct TimeBufferType
	{
		float time;
		D3DXVECTOR3 padding;
		float height;
		D3DXVECTOR3 padding2;
		float width;
		D3DXVECTOR3 padding3;
	};

	struct LightBufferType
	{
		D3DXVECTOR4 ambientColor;
		D3DXVECTOR4 diffuseColor;
		D3DXVECTOR4 lightDirection;
	};
};

#endif