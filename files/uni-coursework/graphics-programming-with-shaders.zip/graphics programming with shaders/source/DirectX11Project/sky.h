// Rachel Crawford (1204444@abertay.ac.uk) 2014

#ifndef SKY_H_
#define SKY_H_

#include <d3d11.h>
#include <dxgi.h>
#include <d3dcommon.h>
#include <D3DX10math.h>

class D3DClass;
class CubemapEffect;

// Class for rendering a cubemapped sky-sphere/ellipsoid
class Sky {
public:
	Sky() {
		m_cubemap_srv = NULL;
		m_index_count = 0;
		m_index_buffer = NULL;
		m_vertex_buffer = NULL;
	}

	bool Initialise(D3DClass* direct3d, HWND hwnd);
	void Shutdown();

	bool Render(D3DClass* direct3d, D3DXMATRIX world_matrix, D3DXMATRIX view_matrix,
		D3DXMATRIX projection_matrix);

private:
	struct Vertex {
		D3DXVECTOR3 position;
	};

	ID3D11ShaderResourceView* m_cubemap_srv;

	CubemapEffect* m_cubemap_effect;

	int m_index_count;
	ID3D11Buffer* m_index_buffer;
	ID3D11Buffer* m_vertex_buffer;
};

#endif // SKY_H_