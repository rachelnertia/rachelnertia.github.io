#include "lab_9_state.h"

#include "cameraclass.h"
#include "tessellationshaderclass.h"
#include "tessellation_mesh.h"
#include "d3dclass.h"
#include "inputclass.h"
#include "helpers.h"

bool Lab9State::Initialize(D3DClass* direct3d, HWND hwnd) {
	bool result = true;

	m_camera = new CameraClass;
	m_camera->SetPosition(0.0f, 0.0f, -5.0f);

	m_position.SetPosition(m_camera->GetPosition().x, m_camera->GetPosition().y,
		m_camera->GetPosition().z);

	m_tessellation_shader = new TessellationShaderClass;
	result = m_tessellation_shader->Initialize(direct3d->GetDevice(), hwnd);
	if (!result) {
		return false;
	}

	m_tessellation_mesh = new TessellationMeshClass;
	result = m_tessellation_mesh->Initialize(direct3d->GetDevice(), L"data/brick1.dds");
	if (!result) {
		return false;
	}

	m_quad = new MeshClass;
	result = m_quad->Initialize(direct3d->GetDevice(), L"data/brick1.dds");
	if (!result) {
		return false;
	}

	return result;
}


bool Lab9State::Shutdown() {
	if (m_camera) {
		delete m_camera;
		m_camera = NULL;
	}
	ShutdownObject(&m_tessellation_shader);
	ShutdownObject(&m_tessellation_mesh);
	ShutdownObject(&m_quad);

	return true;
}


bool Lab9State::HandleInput(InputClass* input, float delta_time) {
	bool keyDown;
	float posX, posY, posZ, rotX, rotY, rotZ;

	// Set the frame time for calculating the updated position.
	m_position.SetFrameTime(delta_time);

	keyDown = input->IsLeftPressed();
	m_position.TurnLeft(keyDown);

	keyDown = input->IsRightPressed();
	m_position.TurnRight(keyDown);

	keyDown = input->IsUpPressed();
	m_position.MoveForward(keyDown);

	keyDown = input->IsDownPressed();
	m_position.MoveBackward(keyDown);

	keyDown = input->IsAPressed();
	m_position.MoveUpward(keyDown);

	keyDown = input->IsZPressed();
	m_position.MoveDownward(keyDown);

	keyDown = input->IsPgUpPressed();
	m_position.LookUpward(keyDown);

	keyDown = input->IsPgDownPressed();
	m_position.LookDownward(keyDown);

	// Get the view point position/rotation.
	m_position.GetPosition(posX, posY, posZ);
	m_position.GetRotation(rotX, rotY, rotZ);

	// Set the position of the camera.
	m_camera->SetPosition(posX, posY, posZ);
	m_camera->SetRotation(rotX, rotY, rotZ);

	if (input->IsKeyPressed(DIK_NUMPADPLUS)) {
		m_tessellation_amount += 0.5f;
	}
	if (input->IsKeyPressed(DIK_NUMPADMINUS)) {
		m_tessellation_amount -= 0.5f;
	}

	return true;
}


bool Lab9State::Render(D3DClass* direct3d) {
	bool result = true;

	D3DXMATRIX worldMatrix, viewMatrix, projectionMatrix;

	// Clear the buffers to begin the scene.
	direct3d->BeginScene(0.1f, 0.1f, 0.1f, 1.0f);

	// Generate the view matrix based on the camera's position.
	m_camera->Render();

	// Get the world, view, and projection matrices from the camera and d3d objects.
	direct3d->GetWorldMatrix(worldMatrix);
	m_camera->GetViewMatrix(viewMatrix);
	direct3d->GetProjectionMatrix(projectionMatrix);

	m_tessellation_mesh->Render(direct3d->GetDeviceContext());

	//m_quad->Render(direct3d->GetDeviceContext());

	m_tessellation_shader->Render(direct3d->GetDeviceContext(), m_tessellation_mesh->GetIndexCount(),
		worldMatrix, viewMatrix, projectionMatrix, m_tessellation_amount);

	// Present the rendered scene to the screen.
	direct3d->EndScene();

	return result;
}