// Rachel Crawford (1204444@abertay.ac.uk) 2014

#ifndef _LIGHTSHADERCLASS_H_
#define _LIGHTSHADERCLASS_H_

#include <d3d11.h>
#include <d3dx10math.h>
#include <d3dx11async.h>
#include <fstream>
#include <vector>
//#include "lightclass.h"
//#include "cameraclass.h"

// Forward declarations
class LightClass;
class CameraClass;

class LightShaderClass
{
public:
	//TODO: Get the commented-out line below to work, if possible
	//static const WCHAR* PS_FILENAME = "light_ps.hlsl";
	static const int MAX_LIGHTS = 4;

	LightShaderClass();
	LightShaderClass(const LightShaderClass&);
	~LightShaderClass();

	bool Initialize(ID3D11Device*, HWND);
	void Shutdown();
	bool Render(ID3D11DeviceContext*, int, D3DXMATRIX, D3DXMATRIX, D3DXMATRIX, 
		ID3D11ShaderResourceView*, std::vector<LightClass*>*, CameraClass*);

private:
	bool InitializeShader(ID3D11Device*, HWND, WCHAR*, WCHAR*);
	void ShutdownShader();
	void OutputShaderErrorMessage(ID3D10Blob*, HWND, WCHAR*);

	bool SetShaderParameters(ID3D11DeviceContext*, D3DXMATRIX, D3DXMATRIX, D3DXMATRIX, 
		ID3D11ShaderResourceView*, std::vector<LightClass*>*, CameraClass*);
	void RenderShader(ID3D11DeviceContext*, int);


	ID3D11VertexShader	*m_vertexShader;
	ID3D11PixelShader	*m_pixelShader;
	ID3D11InputLayout   *m_layout;
	ID3D11SamplerState	*m_sampleState;

	// buffers passed to the vertex shader
	ID3D11Buffer		*m_matrixBuffer;
	ID3D11Buffer		*m_cameraBuffer;
	ID3D11Buffer		*m_vsLightBuffer;
	// buffer passed to the pixel shader
	ID3D11Buffer		*m_psLightBuffer;

	ID3D11Buffer *m_numLightsBuffer;

	ID3D11BlendState	*m_blendState;

	struct MatrixBufferType
	{
		D3DXMATRIX world;
		D3DXMATRIX view;
		D3DXMATRIX projection;
	};

	struct CameraBufferType
	{
		D3DXVECTOR3 cameraPosition;
		float padding;
	};

	struct VSLightBufferType
	{
		D3DXVECTOR4 lightPosition[MAX_LIGHTS];
		float n_lights;
		float padding[3];
	};

	struct PSLightBufferType
	{
		D3DXVECTOR4 ambientColor[MAX_LIGHTS];	//16*4
		D3DXVECTOR4 diffuseColor[MAX_LIGHTS];	//16*4
		D3DXVECTOR4 lightDirection[MAX_LIGHTS]; //16*4
		D3DXVECTOR4 specularColor[MAX_LIGHTS];	//16*4
		float specularPower[MAX_LIGHTS];		//4*4
		float n_lights;							//4
		float padding[3];						//4*3
	};

	// separate buffer because there seem to be packing issues with passing
	// this data in the LightBuffer
	struct NumLightsBufferType
	{
		float n_lights;
		float padding[3];
	};
};

#endif