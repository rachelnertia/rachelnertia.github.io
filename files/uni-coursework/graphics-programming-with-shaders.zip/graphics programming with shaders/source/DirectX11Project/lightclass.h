#ifndef _LIGHTCLASS_H_
#define _LIGHTCLASS_H_

#include <d3dx10math.h>

class LightClass
{
public:
	LightClass();
	LightClass(const LightClass&);
	~LightClass();

	enum LightTypes
	{
		LIGHTTYPE_DIRECTIONAL_ONLY = 0,
		LIGHTTYPE_DIRECTIONAL_AND_AMBIENT,
		//...
		N_LIGHT_TYPES
	};


	void GenerateViewMatrix();
	void GenerateProjectionMatrix(float screen_near, float screen_depth);

	void SetAmbientColor(float, float, float, float);
	void SetDiffuseColor(float, float, float, float);
	void SetSpecularColor(float, float, float, float);
	void SetSpecularPower(float);
	void SetDirection(float, float, float);
	void SetPosition(float, float, float);
	void SetType(LightTypes type);
	void SetLookAt(float x, float y, float z) {
		m_lookat = D3DXVECTOR3(x, y, z);
	}
	
	D3DXVECTOR4 GetAmbientColor();
	D3DXVECTOR4 GetDiffuseColor();
	D3DXVECTOR4 GetSpecularColor();
	float GetSpecularPower();
	D3DXVECTOR4 GetDirection();
	D3DXVECTOR4 GetPosition();
	void GetViewMatrix(D3DXMATRIX&);
	void GetProjectionMatrix(D3DXMATRIX&);
	inline D3DXVECTOR3 GetLookAt() {
		return m_lookat;
	}
	//int GetType();

private:
	D3DXVECTOR4 m_ambientColor;
	D3DXVECTOR4 m_diffuseColor;
	D3DXVECTOR4 m_specularColor;
	float m_specularPower;
	D3DXVECTOR4 m_direction;
	D3DXVECTOR4 m_position;
	int m_type;

	D3DXMATRIX m_view_matrix;
	D3DXMATRIX m_projection_matrix;
	D3DXVECTOR3 m_lookat;
};



#endif