// Rachel Crawford (1204444@abertay.ac.uk) 2014

#ifndef VOXEL_SPACE_DEMO_H_
#define VOXEL_SPACE_DEMO_H_

#include "application_state.h"

#include "cameraclass.h"
#include "voxel_space_demo_effect.h"
#include "targetwindowclass.h"



// Demonstrates Comanche-style 'voxel space' rendering on the GPU using a compute shader.
class VoxelSpaceDemo : public ApplicationState {
public:
	VoxelSpaceDemo() {
		
	}

	bool Initialize(D3DClass* direct3d, HWND hwnd);
	bool Shutdown();
	bool HandleInput(InputClass* input, float delta_time);
	bool Render(D3DClass* direct3d);


private:
	struct VoxelSpaceCamera {
		VoxelSpaceCamera() {
			x = 512.f;
			y = 800.f;
			height = 100.f;
			angle_horizontal = 0.f;
			angle_vertical = 0.f;
		}

		float x;
		float y;
		float height;
		float angle_horizontal;
		float angle_vertical;
	};

	CameraClass m_camera;
	VoxelSpaceCamera m_voxel_space_camera;
	VoxelSpaceDemoEffect m_voxel_space_demo_effect;
	TargetWindowClass m_targetwindow;
};

#endif // VOXEL_SPACE_DEMO_H_ 