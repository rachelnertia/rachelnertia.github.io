#include "voxel_space_demo_effect.h"
#include "helpers.h"

bool VoxelSpaceDemoEffect::Initialize(ID3D11Device* device, HWND hwnd) {
	// Instantiate the compute shader object
	if (!CreateShaderObject(device, hwnd, L"voxel_space_cs.hlsl", "main",
		(ID3D11DeviceChild**)&m_compute_shader, ST_COMPUTE)) {
		return false;
	}

	// Load input colormap and setup the SRV to it.
	HRESULT hr = D3DX11CreateShaderResourceViewFromFile(device, L"data/colormap0.png", NULL,
		NULL, &m_input_colormap_srv, NULL);
	if (FAILED(hr)) {
		return false;
	}
	// Load input heightmap
	hr = D3DX11CreateShaderResourceViewFromFile(device, L"data/heightmap0.png", NULL,
		NULL, &m_input_heightmap_srv, NULL);
	if (FAILED(hr)) {
		return false;
	}

	// Set up the output texture UAV and create the SRV to it.

	D3D11_TEXTURE2D_DESC out_tex_desc;
	out_tex_desc.Width = 800;
	out_tex_desc.Height = 600;
	out_tex_desc.MipLevels = 1;
	out_tex_desc.ArraySize = 1;
	out_tex_desc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	out_tex_desc.SampleDesc.Count = 1;
	out_tex_desc.SampleDesc.Quality = 0;
	out_tex_desc.Usage = D3D11_USAGE_DEFAULT;
	out_tex_desc.BindFlags = D3D11_BIND_SHADER_RESOURCE |
		D3D11_BIND_UNORDERED_ACCESS;
	out_tex_desc.CPUAccessFlags = 0;
	out_tex_desc.MiscFlags = 0;

	// Pointer to the compute shader output texture
	ID3D11Texture2D* cs_output_texture = NULL;
	// Create the output texture
	hr = device->CreateTexture2D(&out_tex_desc, 0,
		&cs_output_texture);
	if (FAILED(hr)) {
		return false;
	}

	// Create a SRV to the compute shader output texture
	D3D11_SHADER_RESOURCE_VIEW_DESC srv_desc;
	srv_desc.Format = out_tex_desc.Format;
	srv_desc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
	srv_desc.Texture2D.MostDetailedMip = 0;
	srv_desc.Texture2D.MipLevels = 1;

	hr = device->CreateShaderResourceView(cs_output_texture,
		&srv_desc, &m_output_texture_srv);
	if (FAILED(hr)) {
		return false;
	}

	// Create a UAV to the compute shader output texture
	D3D11_UNORDERED_ACCESS_VIEW_DESC uav_desc;
	uav_desc.Format = out_tex_desc.Format;
	uav_desc.ViewDimension = D3D11_UAV_DIMENSION_TEXTURE2D;
	uav_desc.Texture2D.MipSlice = 0;

	hr = device->CreateUnorderedAccessView(cs_output_texture,
		&uav_desc, &m_output_texture_uav);
	if (FAILED(hr)) {
		return false;
	}
	// Views save a reference to the texture so we can release this one
	SafeRelease(&cs_output_texture);

	// Set up the constant buffer used to send camera orientation & position data to the
	// compute shader
	{
		D3D11_BUFFER_DESC camera_buffer_desc;
		camera_buffer_desc.Usage = D3D11_USAGE_DYNAMIC;
		camera_buffer_desc.ByteWidth = sizeof(CameraBuffer);
		camera_buffer_desc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
		camera_buffer_desc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
		camera_buffer_desc.MiscFlags = 0;
		camera_buffer_desc.StructureByteStride = 0;

		// Create the constant buffer pointer so we can access the vertex shader constant buffer from within this class.
		HRESULT result = device->CreateBuffer(&camera_buffer_desc, NULL, &m_camera_buffer);
		if (FAILED(result))
		{
			return false;
		}
	}

	// Pass execution up to the parent class
	return Effect::Initialize(device, hwnd);
}


bool VoxelSpaceDemoEffect::Shutdown() {
	SafeRelease(&m_compute_shader);
	SafeRelease(&m_input_colormap_srv);
	SafeRelease(&m_input_heightmap_srv);
	SafeRelease(&m_output_texture_srv);
	SafeRelease(&m_output_texture_uav);
	SafeRelease(&m_camera_buffer);

	return Effect::Shutdown();
}


/*
	Runs the voxel space compute shader using the input texture, then renders the
	output texture to a mesh, which doesn't need to be anything more than a quad.
*/
bool VoxelSpaceDemoEffect::Render(ID3D11DeviceContext* context, int index_count,
	ID3D11ShaderResourceView* texture_srv,
	D3DXMATRIX world_matrix, D3DXMATRIX view_matrix,
	D3DXMATRIX projection_matrix) {
	// Send the camera buffer to the compute shader
	{
		D3D11_MAPPED_SUBRESOURCE mappedResource;
		HRESULT result;
		int bufferNumber = 0;
		
		// Lock the constant buffer so it can be written to.
		result = context->Map(m_camera_buffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedResource);
		if (FAILED(result))
		{
			return false;
		}

		CameraBuffer* camera_buffer_data;
		// Get a pointer to the data in the constant buffer.
		camera_buffer_data = (CameraBuffer*)mappedResource.pData;

		// Copy variables into the constant buffer.
		camera_buffer_data->angle = m_camera_angle_horizontal;
		camera_buffer_data->position = D3DXVECTOR4(m_camera_position_x, m_camera_position_y,
			m_camera_height, m_camera_angle_vertical);

		// Unlock the constant buffer.
		context->Unmap(m_camera_buffer, 0);
		// Finally, set the constant buffer in the pixel shader with the updated values.
		context->CSSetConstantBuffers(bufferNumber, 1, &m_camera_buffer);
	}

	// Run the compute shader:
	// Set the texture sampler state to use in the compute shader
	// (Just use the same one as in the pixel shader.)
	context->CSSetSamplers(0, 1, &m_sampler_state);
	// Pass in the input colormap and heightmap textures.
	context->CSSetShaderResources(0, 1, &m_input_colormap_srv);
	context->CSSetShaderResources(1, 1, &m_input_heightmap_srv);
	// Tell it where to put the finished product.
	context->CSSetUnorderedAccessViews(0, 1, &m_output_texture_uav, 0);

	context->CSSetShader(m_compute_shader, NULL, 0);

	// Dispatch 800 thread groups (one per horizontal pixel)
	context->Dispatch(800, 1, 1);

	// Clean up after running the compute shader.
	{
		context->CSSetShader(NULL, NULL, 0);
		ID3D11UnorderedAccessView* ppUAViewNULL[1] = { NULL };
		ID3D11ShaderResourceView* ppSRVNULL[2] = { NULL, NULL };
		context->CSSetUnorderedAccessViews(0, 1, ppUAViewNULL, NULL);
		context->CSSetShaderResources(0, 2, ppSRVNULL);
	}

	// Send the matrices to the vertex shader
	{
		// Transpose the matrices to prepare them for the shader.
		D3DXMatrixTranspose(&world_matrix, &world_matrix);
		D3DXMatrixTranspose(&view_matrix, &view_matrix);
		D3DXMatrixTranspose(&projection_matrix, &projection_matrix);

		D3D11_MAPPED_SUBRESOURCE mapped_resource;

		// Lock the constant buffer so it can be written to.
		HRESULT result = context->Map(m_matrix_buffer, 0,
			D3D11_MAP_WRITE_DISCARD, 0, &mapped_resource);
		if (FAILED(result))	{
			return false;
		}

		// Get a pointer to the data in the constant buffer.
		MatrixBuffer* matrix_buffer = (MatrixBuffer*)mapped_resource.pData;

		// Copy the matrices into the constant buffer.
		matrix_buffer->world = world_matrix;
		matrix_buffer->view = view_matrix;
		matrix_buffer->projection = projection_matrix;

		// Unlock the constant buffer.
		context->Unmap(m_matrix_buffer, 0);

		// Now set the constant buffer in the vertex shader with the updated 
		// values.
		context->VSSetConstantBuffers(0, 1, &m_matrix_buffer);
	}

	// Set the texture to use in the pixel shader
	context->PSSetShaderResources(0, 1, &m_output_texture_srv);

	// Set the vertex input layout.
	context->IASetInputLayout(m_layout);

	// Set the vertex and pixel shaders that will be used to render this triangle.
	context->VSSetShader(m_vertex_shader, NULL, 0);
	context->PSSetShader(m_pixel_shader, NULL, 0);

	// Set the sampler state in the pixel shader.
	context->PSSetSamplers(0, 1, &m_sampler_state);

	// set the blend state in the pixel shader
	context->OMSetBlendState(m_blend_state, 0, 0xffffffff);

	// Render the triangles.
	context->DrawIndexed(index_count, 0, 0);

	// Clean up.
	{
		context->PSSetShader(NULL, NULL, 0);
		context->VSSetShader(NULL, NULL, 0);
		ID3D11ShaderResourceView* ppSRVNULL[2] = { NULL, NULL };
		context->PSSetShaderResources(0, 2, ppSRVNULL);
	}

	return true;
}


void VoxelSpaceDemoEffect::SetCameraVariables(float angle_horizontal, float position_x, 
	float position_y, float position_z, float angle_vertical) {
	m_camera_angle_horizontal = angle_horizontal;
	m_camera_angle_vertical = angle_vertical;
	m_camera_position_x = position_x;
	m_camera_position_y = position_y;
	m_camera_height = position_z;
}