#include "lab_12_state.h"

#include "d3dclass.h"
#include "cameraclass.h"
#include "planeclass.h"
#include "shadowshaderclass.h"
#include "meshclass.h"
#include "rendertextureclass.h"
#include "lightclass.h"
#include "depthshaderclass.h"
#include "inputclass.h"
#include "positionclass.h"
#include "helpers.h"
#include "particle_emitter.h"


bool Lab12State::Initialize(D3DClass* direct3d, HWND hwnd) {
	ID3D11Device* device = direct3d->GetDevice();

	m_camera = new CameraClass;
	m_camera->SetPosition(0.0f, 0.0f, -5.0f);

	m_position = new PositionClass;
	m_position->SetPosition(m_camera->GetPosition().x, m_camera->GetPosition().y,
		m_camera->GetPosition().z);
	
	m_mesh = new MeshClass;
	if (!m_mesh->Initialize(device, L"data/bumblebee.png")) {
		return false;
	}

	m_particle_emitter = new ParticleEmitter;
	if (!m_particle_emitter->Initialise(device, hwnd)) {
		return false;
	}

	return true;
}


bool Lab12State::Shutdown() {
	delete m_camera;
	m_camera = NULL;

	delete m_position;
	m_position = NULL;

	ShutdownObject(&m_mesh);
	ShutdownObject(&m_particle_emitter);

	return true;
}

bool Lab12State::Update(float delta_time) {
	m_particle_emitter->Update(delta_time);

	return true;
}

bool Lab12State::HandleInput(InputClass* input, float delta_time) {
	bool keyDown;
	float posX, posY, posZ, rotX, rotY, rotZ;

	// Set the frame time for calculating the updated position.
	m_position->SetFrameTime(delta_time);

	keyDown = input->IsLeftPressed();
	m_position->TurnLeft(keyDown);

	keyDown = input->IsRightPressed();
	m_position->TurnRight(keyDown);

	keyDown = input->IsUpPressed();
	m_position->MoveForward(keyDown);

	keyDown = input->IsDownPressed();
	m_position->MoveBackward(keyDown);

	keyDown = input->IsAPressed();
	m_position->MoveUpward(keyDown);

	keyDown = input->IsZPressed();
	m_position->MoveDownward(keyDown);

	keyDown = input->IsPgUpPressed();
	m_position->LookUpward(keyDown);

	keyDown = input->IsPgDownPressed();
	m_position->LookDownward(keyDown);

	// Get the view point position/rotation.
	m_position->GetPosition(posX, posY, posZ);
	m_position->GetRotation(rotX, rotY, rotZ);

	// Set the position of the camera.
	m_camera->SetPosition(posX, posY, posZ);
	m_camera->SetRotation(rotX, rotY, rotZ);

	return true;
}


bool Lab12State::Render(D3DClass* direct3d) {
	D3DXMATRIX worldMatrix, viewMatrix, projectionMatrix;
	bool result;

	// Clear the scene.
	direct3d->BeginScene(0.1f, 0.1f, 0.5f, 1.0f);

	// Generate the view matrix based on the camera's position.
	m_camera->Render();

	// Get the world, view, projection, and ortho matrices from the camera and Direct3D objects.
	direct3d->GetWorldMatrix(worldMatrix);
	m_camera->GetViewMatrix(viewMatrix);
	direct3d->GetProjectionMatrix(projectionMatrix);

	// try out the particle emitter
	m_particle_emitter->Render(direct3d->GetDeviceContext(),
		worldMatrix, viewMatrix, projectionMatrix);


	// Present the rendered scene to the screen.
	direct3d->EndScene();

	return true;
}