// Rachel Crawford (1204444@abertay.ac.uk) 2014

#include "water_demo.h"
#include "cameraclass.h"
#include "positionclass.h"
#include "inputclass.h"
#include "d3dclass.h"
#include "planeclass.h"
#include "helpers.h"
#include "sky.h"
#include "water_effect.h"
#include "tessellation_plane.h"
#include "lightclass.h"
#include "pixelate_shader.h"
#include "rendertextureclass.h"
#include "targetwindowclass.h"


bool WaterDemo::Initialize(D3DClass* direct3d, HWND hwnd) {
	m_camera = new CameraClass;
	m_camera->SetPosition(100.0f, 5.0f, 100.0f);

	m_position = new PositionClass;
	m_position->SetPosition(m_camera->GetPosition().x, m_camera->GetPosition().y,
		m_camera->GetPosition().z);
	
	m_sky = new Sky;
	if (!m_sky->Initialise(direct3d, hwnd)) {
		return false;
	}

	m_water_plane = new PlaneClass;
	if (!m_water_plane->Initialize(direct3d->GetDevice(), L"data/bumblebee.png")) {
		return false;
	}

	m_water_effect = new WaterEffect;
	if (!m_water_effect->Initialize(direct3d->GetDevice(), hwnd)) {
		return false;
	}

	m_water_tess_plane = new TessellationPlane;
	if (!m_water_tess_plane->Initialize(direct3d->GetDevice(), L"data/bumblebee.png")) {
		return false;
	}

	m_pixelate_shader = new PixelateShader;
	if (!m_pixelate_shader->Initialize(direct3d->GetDevice(), hwnd,
		D3D11_FILTER_COMPARISON_MIN_MAG_MIP_POINT)) {
		return false;
	}

	m_render_texture = new RenderTextureClass;
	if (!m_render_texture->Initialize(direct3d->GetDevice(), 800, 600, 400, 300)) {
		return false;
	}

	m_targetwindow = new TargetWindowClass;
	if (!m_targetwindow->Initialize(direct3d->GetDevice(), 800, 600, 800, 600)) {
		return false;
	}


	m_directional_light = new LightClass;
	m_directional_light->SetAmbientColor(0.2f, 0.175f, 0.3f, 1.f);
	m_directional_light->SetDiffuseColor(0.6f, 0.45f, 0.65f, 1.f);
	m_directional_light->SetSpecularColor(0.85f, 0.5f, 0.2f, 1.f);
	m_directional_light->SetSpecularPower(1.f);
	m_directional_light->SetDirection(-0.75f, -0.5f, 1.f);

	return true;
}


bool WaterDemo::Shutdown() {
	delete m_camera;
	m_camera = NULL;

	delete m_position;
	m_position = NULL;

	m_sky->Shutdown();
	delete m_sky;
	m_sky = NULL;

	ShutdownObject(&m_water_plane);
	ShutdownObject(&m_water_effect);
	ShutdownObject(&m_water_tess_plane);
	ShutdownObject(&m_pixelate_shader);
	ShutdownObject(&m_render_texture);
	ShutdownObject(&m_targetwindow);

	delete m_directional_light;
	m_directional_light = NULL;

	return true;
}


bool WaterDemo::HandleInput(InputClass* input, float delta_time) {
	bool keyDown;
	float posX, posY, posZ, rotX, rotY, rotZ;

	// Set the frame time for calculating the updated position.
	m_position->SetFrameTime(delta_time);

	keyDown = input->IsLeftPressed();
	m_position->TurnLeft(keyDown);

	keyDown = input->IsRightPressed();
	m_position->TurnRight(keyDown);

	keyDown = input->IsUpPressed();
	m_position->MoveForward(keyDown);

	keyDown = input->IsDownPressed();
	m_position->MoveBackward(keyDown);

	keyDown = input->IsAPressed();
	m_position->MoveUpward(keyDown);

	keyDown = input->IsZPressed();
	m_position->MoveDownward(keyDown);

	keyDown = input->IsPgUpPressed();
	m_position->LookUpward(keyDown);

	keyDown = input->IsPgDownPressed();
	m_position->LookDownward(keyDown);

	// Get the view point position/rotation.
	m_position->GetPosition(posX, posY, posZ);
	m_position->GetRotation(rotX, rotY, rotZ);

	// Set the position of the camera.
	m_camera->SetPosition(posX, posY, posZ);
	m_camera->SetRotation(rotX, rotY, rotZ);

	if (input->KeyJustPressed(DIK_SPACE)) {
		m_paused = !m_paused;
	}
	
	// update total time elapsed
	if (!m_paused) {
		m_elapsed_time += delta_time;
	}
	
	// increase/decrease tessellation
	if (input->IsKeyPressed(DIK_ADD)) {
		m_tessellation_factor += 0.05f;
		if (m_tessellation_factor > 10.f) {
			m_tessellation_factor = 10.f;
		}
	}
	if (input->IsKeyPressed(DIK_MINUS)) {
		m_tessellation_factor -= 0.05f;
		if (m_tessellation_factor < 1.f) {
			m_tessellation_factor = 1.f;
		}
	}

	// turn the pixelation post-process on/off
	if (input->KeyJustPressed(DIK_P)) {
		m_pixelate = !m_pixelate;
	}

	// increase/decrease pixelation
	if (input->IsKeyPressed(DIK_RBRACKET)) {
		m_pixelation_threshold += 0.001f;
	}
	if (input->IsKeyPressed(DIK_LBRACKET)) {
		m_pixelation_threshold -= 0.001f;
	}

	// increase/decrese the amplitude of all the waves
	if (input->IsKeyPressed(DIK_PERIOD)) {
		m_wave_amplitude_modifier += 0.05f;
	}
	if (input->IsKeyPressed(DIK_COMMA)) {
		m_wave_amplitude_modifier -= 0.05f;
	}

	return true;
}


bool WaterDemo::Render(D3DClass* direct3d) {
	// Depending on whether the pixelation post-processing effect is switched on, either
	// render the scene to a texture, then to the back buffer using the pixelate shader,
	// or just render the scene straight to the back buffer.
	if (m_pixelate) {
		D3DXMATRIX worldMatrix, viewMatrix, orthoMatrix;

		// Get the world, view, and ortho matrices from the camera and d3d objects.
		m_camera->GetBaseViewMatrix(viewMatrix);
		direct3d->GetWorldMatrix(worldMatrix);
		direct3d->GetOrthoMatrix(orthoMatrix);

		// Set the render target to be the render to texture.
		m_render_texture->SetRenderTarget(direct3d->GetDeviceContext());

		// Clear the render to texture.
		m_render_texture->ClearRenderTarget(direct3d->GetDeviceContext(), 0.0f, 0.0f, 1.0f, 1.0f);

		// render the scene to the texture
		if (!RenderScene(direct3d)) {
			return false;
		}

		// Reset the render target back to the original back buffer and not the render to texture anymore.
		direct3d->SetBackBufferRenderTarget();

		// Clear the buffers to begin the scene.
		direct3d->BeginScene(0.1f, 0.1f, 0.1f, 1.0f);

		// Turn off the Z buffer to begin all 2D rendering.
		direct3d->TurnZBufferOff();

		// Put the target window vertex buffer on the graphics pipeline to prepare for drawing.
		m_targetwindow->Render(direct3d->GetDeviceContext());

		// Render the up sample window using the texture shader and the full screen sized blurred render to texture resource.
		if (!m_pixelate_shader->Render(direct3d->GetDeviceContext(),
			m_targetwindow->GetIndexCount(), worldMatrix, viewMatrix, orthoMatrix,
			m_render_texture->GetShaderResourceView(), m_pixelation_threshold)) {
			return false;
		}

		// Turn the Z buffer back on now that all 2D rendering has completed.
		direct3d->TurnZBufferOn();
	} else {
		direct3d->SetBackBufferRenderTarget();

		// Clear the buffers to begin the scene.
		direct3d->BeginScene(0.1f, 0.1f, 0.1f, 1.0f);

		if (!RenderScene(direct3d)) {
			return false;
		}
	}

	// Present the rendered scene to the screen.
	direct3d->EndScene();

	return true;
}


bool WaterDemo::RenderScene(D3DClass* direct3d) {
	D3DXMATRIX worldMatrix, viewMatrix, projectionMatrix;
	
	// Generate the view matrix based on the camera's position.
	m_camera->Render();
	m_camera->GetViewMatrix(viewMatrix);

	// Get the world & projection matrices
	direct3d->GetWorldMatrix(worldMatrix);
	direct3d->GetProjectionMatrix(projectionMatrix);

	// render skysphere
	{
		D3DXMATRIX mt, ms;
		// translate to the camera's position
		D3DXMatrixTranslation(&mt,
			m_camera->GetPosition().x, m_camera->GetPosition().y, m_camera->GetPosition().z);
		// squish the sky-sphere a bit maybe
		D3DXMatrixScaling(&ms, 1000.f, 1000.f, 1000.f);

		worldMatrix = ms * mt;

		m_sky->Render(direct3d, worldMatrix, viewMatrix, projectionMatrix);

		// set the world matrix back
		direct3d->GetWorldMatrix(worldMatrix);
	}

	// render the water
	{
		m_water_tess_plane->Render(direct3d->GetDeviceContext());

		direct3d->GetDeviceContext()->IASetPrimitiveTopology(
			D3D11_PRIMITIVE_TOPOLOGY_4_CONTROL_POINT_PATCHLIST);

		if (!m_water_effect->Render(direct3d->GetDeviceContext(), m_water_plane->GetIndexCount(),
			m_water_plane->GetTexture(),
			worldMatrix, viewMatrix, projectionMatrix,
			// need to slow wave time down because hey why not
			m_elapsed_time*0.001f, m_tessellation_factor,
			m_directional_light, m_camera, m_wave_amplitude_modifier)) {
			return false;
		}
	}

	return true;
}