#include "lab_11_state.h"

#include "d3dclass.h"
#include "cameraclass.h"
#include "planeclass.h"
#include "shadowshaderclass.h"
#include "meshclass.h"
#include "rendertextureclass.h"
#include "lightclass.h"
#include "depthshaderclass.h"
#include "inputclass.h"
#include "positionclass.h"
#include "helpers.h"

const float Lab11State::SCREEN_NEAR	 = 0.1f;
const float Lab11State::SCREEN_DEPTH = 100.f;

bool Lab11State::Initialize(D3DClass* direct3d, HWND hwnd) {
	ID3D11Device* device = direct3d->GetDevice();

	m_camera = new CameraClass;
	m_camera->SetPosition(0, 1, -20);

	m_light = new LightClass;
	m_light->SetDiffuseColor(1, 1, 1, 1);
	m_light->SetAmbientColor(0.25f, 0.25f, 0.25f, 1);
	m_light->SetDirection(0, 0, 1);
	m_light->SetPosition(0, 0, 0);
	m_light->GenerateProjectionMatrix(SCREEN_NEAR, SCREEN_DEPTH);
	m_light->GenerateViewMatrix();
	
	m_plane = new PlaneClass;
	if (!m_plane->Initialize(device, L"data/bumblebee.png")) {
		return false;
	}
	
	m_shadow_shader = new ShadowShaderClass;
	if (!m_shadow_shader->Initialize(device, hwnd)) {
		return false;
	}

	m_mesh = new MeshClass;
	if (!m_mesh->Initialize(device, L"data/bumblebee.png")) {
		return false;
	}

	m_render_texture = new RenderTextureClass;
	if (!m_render_texture->Initialize(device, SHADOWMAP_WIDTH, SHADOWMAP_HEIGHT,
		SCREEN_DEPTH, SCREEN_NEAR)) {
		return false;
	}

	m_depth_shader = new DepthShaderClass;
	if (!m_depth_shader->Initialize(device, hwnd)) {
		return false;
	}

	m_position = new PositionClass;

	return true;
}


bool Lab11State::Shutdown() {
	delete m_camera;
	m_camera = NULL;

	delete m_light;
	m_light = NULL;

	delete m_position;
	m_position = NULL;

	ShutdownObject(&m_plane);
	ShutdownObject(&m_shadow_shader);
	ShutdownObject(&m_mesh);
	ShutdownObject(&m_render_texture);
	ShutdownObject(&m_depth_shader);

	return true;
}


bool Lab11State::HandleInput(InputClass* input, float delta_time) {
	bool keyDown;
	float posX, posY, posZ, rotX, rotY, rotZ;

	// Set the frame time for calculating the updated position.
	m_position->SetFrameTime(delta_time);

	keyDown = input->IsLeftPressed();
	m_position->TurnLeft(keyDown);

	keyDown = input->IsRightPressed();
	m_position->TurnRight(keyDown);

	keyDown = input->IsUpPressed();
	m_position->MoveForward(keyDown);

	keyDown = input->IsDownPressed();
	m_position->MoveBackward(keyDown);

	keyDown = input->IsAPressed();
	m_position->MoveUpward(keyDown);

	keyDown = input->IsZPressed();
	m_position->MoveDownward(keyDown);

	keyDown = input->IsPgUpPressed();
	m_position->LookUpward(keyDown);

	keyDown = input->IsPgDownPressed();
	m_position->LookDownward(keyDown);

	// Get the view point position/rotation.
	m_position->GetPosition(posX, posY, posZ);
	m_position->GetRotation(rotX, rotY, rotZ);

	// Set the position of the camera.
	m_camera->SetPosition(posX, posY, posZ);
	m_camera->SetRotation(rotX, rotY, rotZ);

	// move light around
	float lightX, lightY, lightZ;
	D3DXVECTOR3 lightPos = m_light->GetPosition();
	lightX = lightPos.x;
	lightY = lightPos.y;
	lightZ = lightPos.z;
	const float lightMoveStep = 0.05f;
	if (input->IsKeyPressed(DIK_NUMPAD4))
		lightX -= lightMoveStep;
	if (input->IsKeyPressed(DIK_NUMPAD6))
		lightX += lightMoveStep;
	if (input->IsKeyPressed(DIK_NUMPADMINUS))
		lightY -= lightMoveStep;
	if (input->IsKeyPressed(DIK_NUMPADPLUS))
		lightY += lightMoveStep;
	if (input->IsKeyPressed(DIK_NUMPAD2))
		lightZ -= lightMoveStep;
	if (input->IsKeyPressed(DIK_NUMPAD8))
		lightZ += lightMoveStep;
	m_light->SetPosition(lightX, lightY, lightZ);
	// set the new point for the light to look at
	D3DXVECTOR3 newLookat = m_light->GetPosition() + m_light->GetDirection();
	m_light->SetLookAt(newLookat.x, newLookat.y, newLookat.z);

	return true;
}


bool Lab11State::Render(D3DClass* direct3d) {
	D3DXMATRIX worldMatrix, viewMatrix, projectionMatrix;
	bool result;

	RenderSceneToTexture(direct3d);

	// Clear the scene.
	direct3d->BeginScene(0.0f, 0.0f, 0.0f, 1.0f);

	// Generate the view matrix based on the camera's position.
	m_camera->Render();

	// Get the world, view, projection, and ortho matrices from the camera and Direct3D objects.
	direct3d->GetWorldMatrix(worldMatrix);
	m_camera->GetViewMatrix(viewMatrix);
	direct3d->GetProjectionMatrix(projectionMatrix);

	// Render the plane
	direct3d->GetWorldMatrix(worldMatrix);
	D3DXMatrixTranslation(&worldMatrix, -4.0, -1.0, 0.0);
	m_plane->Render(direct3d->GetDeviceContext());

	result = m_shadow_shader->Render(direct3d->GetDeviceContext(), m_plane->GetIndexCount(),
		worldMatrix, viewMatrix, projectionMatrix, m_plane->GetTexture(), m_render_texture->GetShaderResourceView(), m_light);
	if (!result)
	{
		return false;
	}

	// Render the quad
	direct3d->GetWorldMatrix(worldMatrix);
	D3DXMatrixTranslation(&worldMatrix, -2.0, 0.0, 2.0);
	m_mesh->Render(direct3d->GetDeviceContext());

	result = m_shadow_shader->Render(direct3d->GetDeviceContext(), m_mesh->GetIndexCount(),
		worldMatrix, viewMatrix, projectionMatrix, m_mesh->GetTexture(), m_render_texture->GetShaderResourceView(), m_light);
	if (!result)
	{
		return false;
	}

	

	// Render a sphere????
	/*direct3d->GetWorldMatrix(worldMatrix);
	D3DXMatrixTranslation(&worldMatrix, 2.0, 1.0, 0.0);
	m_sphere->Render(direct3d->GetDeviceContext());
	result = m_shadow_shader->Render(direct3d->GetDeviceContext(), m_sphere->GetIndexCount(), worldMatrix, viewMatrix, projectionMatrix, m_sphere->GetTexture(), m_render_texture->GetShaderResourceView(), m_light);
	if (!result)
	{
		return false;
	}*/

	// Present the rendered scene to the screen.
	direct3d->EndScene();

	return true;
}

bool Lab11State::RenderSceneToTexture(D3DClass* direct3d)
{
	// for shadows.
	D3DXMATRIX worldMatrix, viewMatrix, projectionMatrix, lightViewMatrix, lightProjectionMatrix;
	bool result;

	// Set the render target to be the render to texture.
	m_render_texture->SetRenderTarget(direct3d->GetDeviceContext());

	// Clear the render to texture.
	m_render_texture->ClearRenderTarget(direct3d->GetDeviceContext(), 0.0f, 0.0f, 0.0f, 1.0f);

	// Get the world, view, and projection matrices from the light and d3d objects.
	m_light->GenerateViewMatrix();
	m_light->GenerateProjectionMatrix(SCREEN_NEAR, SCREEN_DEPTH);

	m_light->GetViewMatrix(lightViewMatrix);
	m_light->GetProjectionMatrix(lightProjectionMatrix);

	direct3d->GetWorldMatrix(worldMatrix);
	D3DXMatrixTranslation(&worldMatrix, -4.0, -1.0, 0.0);
	m_plane->Render(direct3d->GetDeviceContext());
	result = m_depth_shader->Render(direct3d->GetDeviceContext(), m_plane->GetIndexCount(), worldMatrix, lightViewMatrix, lightProjectionMatrix);
	if (!result)
	{
		return false;
	}

	direct3d->GetWorldMatrix(worldMatrix);
	D3DXMatrixTranslation(&worldMatrix, -2.0, 0.0, 2.0);
	m_mesh->Render(direct3d->GetDeviceContext());
	result = m_depth_shader->Render(direct3d->GetDeviceContext(), m_mesh->GetIndexCount(), worldMatrix, lightViewMatrix, lightProjectionMatrix);
	if (!result)
	{
		return false;
	}

	/*direct3d->GetWorldMatrix(worldMatrix);
	D3DXMatrixTranslation(&worldMatrix, 2.0, 1.0, 0.0);
	m_sphere->Render(direct3d->GetDeviceContext());
	result = m_depth_shader->Render(direct3d->GetDeviceContext(), m_sphere->GetIndexCount(), worldMatrix, lightViewMatrix, lightProjectionMatrix);
	if (!result)
	{
		return false;
	}*/

	// Reset the render target back to the original back buffer and not the render to texture anymore.
	direct3d->SetBackBufferRenderTarget();

	// Reset the viewport back to the original.
	direct3d->ResetViewport();

	return true;
}