// Rachel Crawford (1204444@abertay.ac.uk) 2014

#ifndef EFFECT_H_
#define EFFECT_H_

#include <d3d11.h>
#include <d3dx10math.h>
#include <d3dx11async.h>

class MeshClass;

//! Base class for rendering effects.
/*!
	An Effect is a combination of different shaders used when rendering
	a mesh. This base class tries to encapsulate the things which are 
	common to all of them. Perhaps a better name would be a 'pipeline',
	as it essentially defines the entire rendering process.  
*/
class Effect {
public:
	Effect();
	virtual ~Effect();

	virtual bool Initialize(ID3D11Device* device, HWND hwnd);
	virtual bool Shutdown();

	virtual bool Render(ID3D11DeviceContext* context, int index_count,
		ID3D11ShaderResourceView* texture_srv,
		D3DXMATRIX world_matrix, D3DXMATRIX view_matrix,
		D3DXMATRIX projection_matrix);
	virtual bool Render(ID3D11DeviceContext* context, MeshClass* mesh,
		D3DXMATRIX world_matrix, D3DXMATRIX view_matrix,
		D3DXMATRIX projection_matrix);

protected:
	struct MatrixBuffer	{
		D3DXMATRIX world;
		D3DXMATRIX view;
		D3DXMATRIX projection;
	};

	// Used in the shader compilation & creation phase for flow control.
	enum ShaderType {
		ST_VERTEX = 0,
		ST_PIXEL,
		ST_COMPUTE,
		ST_GEOMETRY,
		ST_DOMAIN,
		ST_HULL,
		N_SHADERTYPES
	};

	bool CreateShaderObject(ID3D11Device* device, HWND hwnd, WCHAR* filename,
		char* entrypoint, ID3D11DeviceChild** shader, ShaderType type);
	bool CompileShader(WCHAR* filename, char* entrypoint,
		ID3D10Blob** buffer, ShaderType type, HWND hwnd);
	bool CreateMatrixBuffer(ID3D11Device* device);
	virtual bool CreateSampler(ID3D11Device* device);
	virtual bool CreateBlender(ID3D11Device* device);
	virtual bool CreateVertexShaderInputLayout(ID3D11Device* device,
		ID3D10Blob* vs_bytecode);

	ID3D11VertexShader*	m_vertex_shader;
	ID3D11PixelShader*	m_pixel_shader;	

	ID3D11Buffer*		m_matrix_buffer;

	ID3D11SamplerState* m_sampler_state;
	ID3D11BlendState*	m_blend_state;

	ID3D11InputLayout*	m_layout;

private:
	
	void OutputShaderErrorMessage(ID3D10Blob* errorMessage,
		HWND hwnd, WCHAR* shaderFilename);	
	
};

#endif // EFFECT_H_