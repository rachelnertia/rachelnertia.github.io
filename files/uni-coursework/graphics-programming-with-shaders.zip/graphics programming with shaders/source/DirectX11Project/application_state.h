#ifndef APPLICATION_STATE_H_
#define APPLICATION_STATE_H_

#include <dxgi.h>
#include <d3dcommon.h>
#include <d3d11.h>
#include <d3dx10math.h>

class InputClass;
class D3DClass;


class ApplicationState {
public:
	virtual ~ApplicationState() {}
	virtual bool Initialize(D3DClass* direct3d, HWND hwnd) { return true; }
	virtual bool Shutdown() { return true; }
	virtual bool HandleInput(InputClass* input, float delta_time) { return true; }
	virtual bool Update(float delta_time) { return true; }
	virtual bool Render(D3DClass* direct3d) { return true; }
};


#endif // APPLICATION_STATE_H_