// Rachel Crawford (1204444@abertay.ac.uk) 2014

#include "effect.h"

#include <fstream>

#include "helpers.h"
#include "meshclass.h"


Effect::Effect() 
	: m_vertex_shader(NULL),
	  m_pixel_shader(NULL),
	  m_layout(NULL),
	  m_matrix_buffer(NULL),
	  m_sampler_state(NULL),
	  m_blend_state(NULL) {
	
}



Effect::~Effect() {

}



bool Effect::Initialize(ID3D11Device* device, HWND hwnd) {
	// Create the pixel shader
	if (!CreateShaderObject(device, hwnd, L"texture_ps.hlsl", "TexturePixelShader",
		(ID3D11DeviceChild**)&m_pixel_shader, ST_PIXEL)) {
		return false;
	}
	// Create the vertex shader
	if (!CreateShaderObject(device, hwnd, L"texture_vs.hlsl", "TextureVertexShader",
		(ID3D11DeviceChild**)&m_vertex_shader, ST_VERTEX)) {
		return false;
	}

	if (!CreateMatrixBuffer(device)) {
		return false;
	}

	if (!CreateSampler(device)) {
		return false;
	}

	if (!CreateBlender(device)) {
		return false;
	}

	return true;
}



bool Effect::Shutdown() {
	// Safely clean up member variables.
	SafeRelease(&m_vertex_shader);
	SafeRelease(&m_pixel_shader);
	SafeRelease(&m_layout);
	SafeRelease(&m_matrix_buffer);
	SafeRelease(&m_sampler_state);
	SafeRelease(&m_blend_state);
	return true;
}



bool Effect::Render(ID3D11DeviceContext* context,int index_count,
	ID3D11ShaderResourceView* texture_srv,
	D3DXMATRIX world_matrix, D3DXMATRIX view_matrix, 
	D3DXMATRIX projection_matrix) {
	// Send the matrices to the vertex shader
	{
		// Transpose the matrices to prepare them for the shader.
		D3DXMatrixTranspose(&world_matrix, &world_matrix);
		D3DXMatrixTranspose(&view_matrix, &view_matrix);
		D3DXMatrixTranspose(&projection_matrix, &projection_matrix);

		D3D11_MAPPED_SUBRESOURCE mapped_resource;

		// Lock the constant buffer so it can be written to.
		HRESULT result = context->Map(m_matrix_buffer, 0,
			D3D11_MAP_WRITE_DISCARD, 0, &mapped_resource);
		if (FAILED(result))	{
			return false;
		}

		// Get a pointer to the data in the constant buffer.
		MatrixBuffer* matrix_buffer = (MatrixBuffer*)mapped_resource.pData;

		// Copy the matrices into the constant buffer.
		matrix_buffer->world = world_matrix;
		matrix_buffer->view = view_matrix;
		matrix_buffer->projection = projection_matrix;

		// Unlock the constant buffer.
		context->Unmap(m_matrix_buffer, 0);

		// Now set the constant buffer in the vertex shader with the updated 
		// values.
		context->VSSetConstantBuffers(0, 1, &m_matrix_buffer);
	}

	// Set the texture to use in the pixel shader
	context->PSSetShaderResources(0, 1, &texture_srv);

	// Set the vertex input layout.
	context->IASetInputLayout(m_layout);

	// Set the vertex and pixel shaders that will be used to render this triangle.
	context->VSSetShader(m_vertex_shader, NULL, 0);
	context->PSSetShader(m_pixel_shader, NULL, 0);

	// Set the sampler state in the pixel shader.
	context->PSSetSamplers(0, 1, &m_sampler_state);

	// set the blend state in the pixel shader
	context->OMSetBlendState(m_blend_state, 0, 0xffffffff);

	// Render the triangle.
	context->DrawIndexed(index_count, 0, 0);

	return true;
}


bool Effect::Render(ID3D11DeviceContext* context, MeshClass* mesh,
	D3DXMATRIX world_matrix, D3DXMATRIX view_matrix,
	D3DXMATRIX projection_matrix) {

	// Push the mesh's vertex and index buffers onto the GPU
	mesh->Render(context);

	return Render(context, mesh->GetIndexCount(), mesh->GetTexture(), world_matrix,
		view_matrix, projection_matrix);
}


bool Effect::CreateShaderObject(ID3D11Device* device, HWND hwnd, WCHAR* filename,
	char* entrypoint, ID3D11DeviceChild** shader, ShaderType type) {
	HRESULT result = 0;
	// Stores the bytecode from shader compilation
	ID3D10Blob* buffer = NULL;

	// Compile the vertex shader code, storing the result in the buffer
	if (!CompileShader(filename, entrypoint, &buffer, type, hwnd)) {
		return false;
	}

	// Create the shader
	switch (type) {
	case ST_VERTEX:
		result = device->CreateVertexShader(buffer->GetBufferPointer(),
			buffer->GetBufferSize(), NULL, (ID3D11VertexShader**)shader);
		// Set up the vertex input layout for the vertex shader
		CreateVertexShaderInputLayout(device, buffer);
		break;
	case ST_PIXEL:
		result = device->CreatePixelShader(buffer->GetBufferPointer(),
			buffer->GetBufferSize(), NULL, (ID3D11PixelShader**)shader);
		break;
	case ST_COMPUTE:
		result = device->CreateComputeShader(buffer->GetBufferPointer(),
			buffer->GetBufferSize(), NULL, (ID3D11ComputeShader**)shader);
		break;
	case ST_GEOMETRY:
		result = device->CreateGeometryShader(buffer->GetBufferPointer(),
			buffer->GetBufferSize(), NULL, (ID3D11GeometryShader**)shader);
		break;
	case ST_DOMAIN:
		result = device->CreateDomainShader(buffer->GetBufferPointer(),
			buffer->GetBufferSize(), NULL, (ID3D11DomainShader**)shader);
		break;
	case ST_HULL:
		result = device->CreateHullShader(buffer->GetBufferPointer(),
			buffer->GetBufferSize(), NULL, (ID3D11HullShader**)shader);
		break;
	default:
		return false;
	}
	
	if (FAILED(result)) {
		return false;
	}

	SafeRelease(&buffer);

	return true;
}



bool Effect::CreateSampler(ID3D11Device* device) {
	// Texture sampler state description.
	D3D11_SAMPLER_DESC samplerDesc;
	samplerDesc.Filter = D3D11_FILTER_COMPARISON_MIN_MAG_MIP_LINEAR;
	samplerDesc.AddressU = D3D11_TEXTURE_ADDRESS_WRAP;
	samplerDesc.AddressV = D3D11_TEXTURE_ADDRESS_WRAP;
	samplerDesc.AddressW = D3D11_TEXTURE_ADDRESS_WRAP;
	samplerDesc.MipLODBias = 0.0f;
	samplerDesc.MaxAnisotropy = 1;
	samplerDesc.ComparisonFunc = D3D11_COMPARISON_ALWAYS;
	samplerDesc.BorderColor[0] = 0;
	samplerDesc.BorderColor[1] = 0;
	samplerDesc.BorderColor[2] = 0;
	samplerDesc.BorderColor[3] = 0;
	samplerDesc.MinLOD = 0;
	samplerDesc.MaxLOD = D3D11_FLOAT32_MAX;

	// Create the texture sampler state.
	HRESULT result = device->CreateSamplerState(&samplerDesc, &m_sampler_state);
	if (FAILED(result))
	{
		return false;
	}

	return true;
}



bool Effect::CreateBlender(ID3D11Device* device) {
	D3D11_BLEND_DESC blendDesc;
	ZeroMemory(&blendDesc, sizeof(D3D11_BLEND_DESC));
	blendDesc.RenderTarget[0].BlendEnable = true;
	blendDesc.RenderTarget[0].SrcBlend = D3D11_BLEND_SRC_ALPHA;
	blendDesc.RenderTarget[0].DestBlend = D3D11_BLEND_INV_SRC_ALPHA;
	blendDesc.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
	blendDesc.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE;
	blendDesc.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_ZERO;
	blendDesc.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;
	blendDesc.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
	//create the blender state
	HRESULT result = device->CreateBlendState(&blendDesc, &m_blend_state);
	if (FAILED(result))
	{
		return false;
	}

	return true;
}



//! Compiles a file containing shader code.
/*!
@param[in]	filename	Filename of the shader code to be compiled.
@param[in]	entrypoint	Name of the shader's main function.
@param[out] buffer		Buffer to contain the compiled bytecode.
@param[in]	type		Type of shader (e.g. ST_VERTEX for a vertex shader).
@param[in]	hwnd		Handle to the window for outputting error messages.
@return					Whether the operation was successful or not.
*/
bool Effect::CompileShader(WCHAR* filename, char* entrypoint,
	ID3D10Blob** buffer, ShaderType type, HWND hwnd) {
	ID3D10Blob* error_message = NULL;
	LPCSTR profile;
	// Select which compiler profile to use depending on the type of the shader.
	switch (type) {
	case ST_VERTEX:		profile = "vs_5_0"; break;
	case ST_PIXEL:		profile = "ps_5_0"; break;
	case ST_COMPUTE:	profile = "cs_5_0"; break;
	case ST_GEOMETRY:	profile = "gs_5_0"; break;
	case ST_HULL:		profile = "hs_5_0"; break;
	case ST_DOMAIN:		profile = "ds_5_0"; break;
	default: return false;
	}
	// Compile the vertex shader code, storing the result in the buffer
	HRESULT hr = D3DX11CompileFromFile(filename,
		NULL, NULL, entrypoint, profile,
		D3D10_SHADER_ENABLE_STRICTNESS, 0, NULL, buffer,
		&error_message, &hr);
	if (FAILED(hr)) {
		if (error_message) {
			// TODO: handle compilation error
			OutputShaderErrorMessage(error_message, hwnd, filename);
		}
		else {
			// Couldn't find the shader file
			MessageBox(hwnd, filename, L"Missing shader file", MB_OK);
		}
		return false;
	}
	return true;
}



void Effect::OutputShaderErrorMessage(ID3D10Blob* errorMessage,
	HWND hwnd, WCHAR* shaderFilename)
{
	char* compileErrors;
	unsigned long bufferSize, i;
	std::ofstream fout;


	// Get a pointer to the error message text buffer.
	compileErrors = (char*)(errorMessage->GetBufferPointer());

	// Get the length of the message.
	bufferSize = errorMessage->GetBufferSize();

	// Open a file to write the error message to.
	fout.open("shader-error.txt");

	// Write out the error message.
	for (i = 0; i<bufferSize; i++)
	{
		fout << compileErrors[i];
	}

	// Close the file.
	fout.close();

	// Release the error message.
	errorMessage->Release();
	errorMessage = 0;

	// Pop a message up on the screen to notify the user to check the text file for compile errors.
	MessageBox(hwnd, L"Error compiling shader.  Check shader-error.txt for message.", shaderFilename, MB_OK);

	return;
}



bool Effect::CreateVertexShaderInputLayout(ID3D11Device* device,
	ID3D10Blob* vs_bytecode) {
	D3D11_INPUT_ELEMENT_DESC polygonLayout[3];
	unsigned int numElements;

	// Create the vertex input layout description.
	// This setup needs to match the VertexType stucture in the MeshClass and
	// in the shader.
	polygonLayout[0].SemanticName = "POSITION";
	polygonLayout[0].SemanticIndex = 0;
	polygonLayout[0].Format = DXGI_FORMAT_R32G32B32_FLOAT;
	polygonLayout[0].InputSlot = 0;
	polygonLayout[0].AlignedByteOffset = 0;
	polygonLayout[0].InputSlotClass = D3D11_INPUT_PER_VERTEX_DATA;
	polygonLayout[0].InstanceDataStepRate = 0;

	polygonLayout[1].SemanticName = "TEXCOORD";
	polygonLayout[1].SemanticIndex = 0;
	polygonLayout[1].Format = DXGI_FORMAT_R32G32_FLOAT;
	polygonLayout[1].InputSlot = 0;
	polygonLayout[1].AlignedByteOffset = D3D11_APPEND_ALIGNED_ELEMENT;
	polygonLayout[1].InputSlotClass = D3D11_INPUT_PER_VERTEX_DATA;
	polygonLayout[1].InstanceDataStepRate = 0;

	polygonLayout[2].SemanticName = "NORMAL";
	polygonLayout[2].SemanticIndex = 0;
	polygonLayout[2].Format = DXGI_FORMAT_R32G32B32_FLOAT;
	polygonLayout[2].InputSlot = 0;
	polygonLayout[2].AlignedByteOffset = D3D11_APPEND_ALIGNED_ELEMENT;
	polygonLayout[2].InputSlotClass = D3D11_INPUT_PER_VERTEX_DATA;
	polygonLayout[2].InstanceDataStepRate = 0;

	// Get a count of the elements in the layout.
	numElements = sizeof(polygonLayout) / sizeof(polygonLayout[0]);

	// Create the vertex input layout.
	HRESULT result = device->CreateInputLayout(polygonLayout, numElements,
		vs_bytecode->GetBufferPointer(),
		vs_bytecode->GetBufferSize(), &m_layout);
	if (FAILED(result))
	{
		return false;
	}

	return true;
}



bool Effect::CreateMatrixBuffer(ID3D11Device* device) {
	// The description of the dynamic matrix constant buffer that 
	// is in the vertex shader.
	D3D11_BUFFER_DESC matrixBufferDesc;
	matrixBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
	matrixBufferDesc.ByteWidth = sizeof(MatrixBuffer);
	matrixBufferDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
	matrixBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
	matrixBufferDesc.MiscFlags = 0;
	matrixBufferDesc.StructureByteStride = 0;

	// Create the constant buffer pointer so we can access the vertex shader 
	// constant buffer from within this class.
	HRESULT result = device->CreateBuffer(&matrixBufferDesc, NULL,
		&m_matrix_buffer);
	if (FAILED(result))
	{
		return false;
	}

	return true;
}