// Rachel Crawford (1204444@abertay.ac.uk) 2014

#ifndef PARTICLE_EMITTER_H_
#define PARTICLE_EMITTER_H_

#include <d3d11.h>
#include <D3DX10math.h>

class ParticleEffect;


// Uses a ParticleEffect to render a list of points (particles) as billboarded sprites.
class ParticleEmitter {
public:
	ParticleEmitter() {
		m_position = D3DXVECTOR3(0, 0, 0);
		//m_vertex_count = 1;
		//m_index_count = 1;
		//m_index_buffer = NULL;
		m_vertex_buffer = NULL;
		//m_particle.position = D3DXVECTOR3(0, 1, 0);
		m_particle_effect = NULL;
		m_texture_srv = NULL;
		//m_particle_positions = NULL;
		m_num_active_particles = 0;
	}


	bool Initialise(ID3D11Device* device, HWND hwnd);
	bool Shutdown();

	bool Render(ID3D11DeviceContext* context, D3DXMATRIX world_matrix,
		D3DXMATRIX view_matrix, D3DXMATRIX projection_matrix);

	bool Update(float delta_time);

	inline D3DXVECTOR3 GetPosition() {
		return m_position;
	}


	inline void SetPosition(D3DXVECTOR3& position) {
		m_position = position;
	}

private:
	// How many points there are.
	static const int MAX_PARTICLES = 150;

	bool InitialiseVertexBuffer(ID3D11Device* device);

	bool NewParticle();

	bool RemoveParticle(int index);

	D3DXVECTOR3 m_position;

	int m_num_active_particles;
	
	D3DXVECTOR3 m_particle_positions[MAX_PARTICLES];
	float m_particle_lifetimes[MAX_PARTICLES];

	ID3D11Buffer* m_vertex_buffer;

	ParticleEffect* m_particle_effect;

	// The texture to use for the particles.
	ID3D11ShaderResourceView* m_texture_srv;
};

#endif // PARTICLE_EMITTER_H_