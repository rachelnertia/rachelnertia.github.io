#ifndef _APPLICATIONCLASS_H_
#define _APPLICATIONCLASS_H_

const bool FULL_SCREEN = false;
const bool VSYNC_ENABLED = true;
const float SCREEN_DEPTH = 1000.0f;
const float SCREEN_NEAR = 0.1f;

#include <vector>

#include "inputclass.h"
#include "d3dclass.h"
#include "timerclass.h"
#include "application_state.h"
#include "voxel_space_demo.h"
#include "lab_12_state.h"
#include "water_demo.h"

// Top-level class.
class Application {
public:
	Application();
	Application(const Application&);
	~Application();

	bool Initialize(HINSTANCE, HWND, int, int);
	void Shutdown();
	bool Frame();

private:
	bool InitializeStates(HWND hwnd);
	bool ShutdownStates();

	ApplicationState*	m_current_state;

	VoxelSpaceDemo		m_voxel_space_demo_state;	// weirdness
	Lab12State			m_lab_12_state;				// point-sprite expansion
	WaterDemo			m_water_demo_state;			// yumness

	InputClass*		m_input;
	D3DClass*		m_direct3d;
	TimerClass*		m_timer;

	D3D11_FILL_MODE m_current_fill_mode;
	D3D11_CULL_MODE m_current_cull_mode;
};

#endif