#ifndef LAB_12_STATE_H_
#define LAB_12_STATE_H_

#include "application_state.h"

class CameraClass;
class PlaneClass;
class ShadowShaderClass;
class MeshClass;
class RenderTextureClass;
class LightClass;
class DepthShaderClass;
class PositionClass;
class ParticleEmitter;


class Lab12State : public ApplicationState {
public:
	Lab12State() {
		m_camera = NULL;
		m_mesh = NULL;
		m_particle_emitter = NULL;
		m_position = NULL;
	}

	bool Initialize(D3DClass* direct3d, HWND hwnd);
	bool Shutdown();
	bool Update(float delta_time);
	bool HandleInput(InputClass* input, float delta_time);
	bool Render(D3DClass* direct3d);
private:
	CameraClass*			m_camera;
	MeshClass*				m_mesh;
	PositionClass*			m_position;
	ParticleEmitter*		m_particle_emitter;
};

#endif // LAB_12_STATE_H_