////////////////////////////////////////////////////////////////////////////////
// Filename: applicationclass.cpp
////////////////////////////////////////////////////////////////////////////////
#include "application.h"
#include "helpers.h"



Application::Application() { 
	m_current_state = NULL;
	m_input	= NULL;
	m_direct3d = NULL;
	m_timer = NULL;
}


Application::Application(const Application& other) {

}


Application::~Application() {

}


bool Application::Initialize(HINSTANCE hinstance, HWND hwnd, int screenWidth, int screenHeight)
{
	bool result;
	
	// Create the Direct3D object.
	m_direct3d = new D3DClass;
	if (!m_direct3d)
	{
		return false;
	}
	// Initialize the Direct3D object.
	result = m_direct3d->Initialize(screenWidth, screenHeight, VSYNC_ENABLED, hwnd,
		FULL_SCREEN, SCREEN_DEPTH, SCREEN_NEAR);
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize DirectX 11.", L"Error", MB_OK);
		return false;
	}

	// Create the input object.  The input object will be used to handle reading the keyboard and mouse input from the user.
	m_input = new InputClass;
	if (!m_input)
	{
		return false;
	}

	// Initialize the input object.
	result = m_input->Initialize(hinstance, hwnd, screenWidth, screenHeight);
	if (!result)
	{
		MessageBox(hwnd, L"Could not initialize the input object.", L"Error", MB_OK);
		return false;
	}

	// Create the timer object.
	m_timer = new TimerClass;
	if(!m_timer)
	{
		return false;
	}

	// Initialize the timer object.
	result = m_timer->Initialize();
	if(!result)
	{
		MessageBox(hwnd, L"Could not initialize the timer object.", L"Error", MB_OK);
		return false;
	}

	// Initialise all the ApplicationStates
	if (!InitializeStates(hwnd)) {
		return false;
	}

	m_current_state = &m_water_demo_state;

	return true;
}


void Application::Shutdown()
{
	ShutdownStates();

	// Release the timer object.
	if(m_timer)
	{
		delete m_timer;
		m_timer = NULL;
	}

	// Release the Direct3D object.
	if(m_direct3d)
	{
		m_direct3d->Shutdown();
		delete m_direct3d;
		m_direct3d = NULL;
	}

	// Release the input object.
	if(m_input)
	{
		m_input->Shutdown();
		delete m_input;
		m_input = NULL;
	}

	return;
}


bool Application::Frame()
{
	bool result;

	// Update the system stats.
	m_timer->Frame();

	// Read the user input.
	result = m_input->Frame();
	if(!result)
	{
		return false;
	}
	
	// Check if the user pressed escape and wants to exit the application.
	if(m_input->IsEscapePressed() == true)
	{
		return false;
	}
	
	// Handle input.
	// switches the rasteriser fill mode between wireframe and solid
	if (m_input->KeyJustPressed(DIK_F))
	{
		m_current_fill_mode = m_current_fill_mode == D3D11_FILL_WIREFRAME ?
		D3D11_FILL_SOLID : D3D11_FILL_WIREFRAME;

		m_direct3d->SetFillMode(m_current_fill_mode);
	}

	// switches backface culling on and off
	if (m_input->KeyJustPressed(DIK_G))
	{
		m_current_cull_mode = (m_current_cull_mode == D3D11_CULL_BACK) ?
		D3D11_CULL_NONE : D3D11_CULL_BACK;

		m_direct3d->SetCullMode(m_current_cull_mode);
	}

	// switch between ApplicationStates on number key presses
	if (m_input->KeyJustPressed(DIK_1)) {
		m_current_state = &m_voxel_space_demo_state;
	}
	else if (m_input->KeyJustPressed(DIK_2)) {
		m_current_state = &m_water_demo_state;
	}
	else if (m_input->KeyJustPressed(DIK_3)) {
		m_current_state = &m_lab_12_state;
	}

	// pass input handling down to the current ApplicationState
	if (!m_current_state->HandleInput(m_input, m_timer->GetTime())) {
		return false;
	}

	// Run update logic.
	if (!m_current_state->Update(m_timer->GetTime())) {
		return false;
	}

	// Render the graphics.
	if (!m_current_state->Render(m_direct3d)) {
		return false;
	}

	return result;
}


bool Application::InitializeStates(HWND hwnd) {
	if (!m_lab_12_state.Initialize(m_direct3d, hwnd)) {
		return false;
	}

	if (!m_voxel_space_demo_state.Initialize(m_direct3d, hwnd)) {
		return false;
	}

	if (!m_water_demo_state.Initialize(m_direct3d, hwnd)) {
		return false;
	}

	return true;
}


bool Application::ShutdownStates() {
	m_lab_12_state.Shutdown();
	m_voxel_space_demo_state.Shutdown();
	m_water_demo_state.Shutdown();

	return true;
}
