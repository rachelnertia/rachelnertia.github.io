#ifndef LAB_9_STATE_H_
#define LAB_9_STATE_H_

#include "application_state.h"

#include "positionclass.h"

class TessellationMeshClass;
class TessellationShaderClass;
class CameraClass;
class MeshClass;

// Figuring out tesselation.
class Lab9State : public ApplicationState {
public:
	Lab9State()
		: m_camera(NULL),
		m_tessellation_shader(NULL),
		m_tessellation_mesh(NULL),
		m_quad(NULL),
		m_tessellation_amount(1.f)
	{}
	bool Initialize(D3DClass* direct3d, HWND hwnd);
	bool Shutdown();
	bool HandleInput(InputClass* input, float delta_time);
	bool Render(D3DClass* direct3d);
private:
	CameraClass*	m_camera;

	TessellationShaderClass* m_tessellation_shader;
	TessellationMeshClass* m_tessellation_mesh;
	MeshClass* m_quad;

	PositionClass m_position;

	float m_tessellation_amount;
};

#endif // LAB_9_STATE_H_