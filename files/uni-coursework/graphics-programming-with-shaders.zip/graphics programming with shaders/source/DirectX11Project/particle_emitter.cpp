#include "particle_emitter.h"

#include "particle_effect.h"
#include "helpers.h"


bool ParticleEmitter::Initialise(ID3D11Device* device, HWND hwnd) {
	// load shaders
	m_particle_effect = new ParticleEffect;
	if (!m_particle_effect->Initialize(device, hwnd)) {
		return false;
	}

	// load texture(s)
	HRESULT hr = D3DX11CreateShaderResourceViewFromFile(device, L"data/fireparticle.png", NULL,
		NULL, &m_texture_srv, NULL);
	if (FAILED(hr)) {
		return false;
	}

	// initialise particles
	{
		for (int i = 0; i < MAX_PARTICLES; i++) {
			m_particle_positions[i] = D3DXVECTOR3(0.f, 0.f, 0.f);
			m_particle_lifetimes[i] = 0.f;
		}
	}

	//m_num_active_particles = 2;
	//m_particle_positions[0] = D3DXVECTOR3(0.f, 0.f, 0.f);
	//m_particle_positions[1] = D3DXVECTOR3(0.5f, 0.f, 0.f);

	// set up the vertex buffer
	InitialiseVertexBuffer(device);

	return true;
}


bool ParticleEmitter::Shutdown() {
	SafeRelease(&m_texture_srv);
	SafeRelease(&m_vertex_buffer);
	ShutdownObject(&m_particle_effect);

	//delete[] m_particle_positions;
	//m_particle_positions = NULL;

	return true;
}


bool ParticleEmitter::Render(ID3D11DeviceContext* context, 
	D3DXMATRIX world_matrix, D3DXMATRIX view_matrix, D3DXMATRIX projection_matrix) {
	// put particle positions into the vertex buffer
	{
		D3D11_MAPPED_SUBRESOURCE mappedResource;
		ZeroMemory(&mappedResource, sizeof(D3D11_MAPPED_SUBRESOURCE));
		// Disable GPU access to the vertex buffer
		context->Map(m_vertex_buffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedResource);
		// Update the vertex buffer with the new positions of particles
		// TODO: Only copy members of the active set into the buffer to save effort
		memcpy(mappedResource.pData, m_particle_positions, 
			sizeof(m_particle_positions[0]) * MAX_PARTICLES);
		// Reenable GPU access to the vertex buffer data
		context->Unmap(m_vertex_buffer, 0);
	}
	
	// push point list onto the hardware
	{
		// Set vertex buffer stride and offset.
		unsigned int stride = sizeof(m_particle_positions[0]);
		unsigned int offset = 0;

		// Set the vertex buffer to active in the input assembler so it can be rendered.
		context->IASetVertexBuffers(0, 1, &m_vertex_buffer, &stride, &offset);

		// Set the type of primitive that should be rendered from this vertex buffer.
		context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_POINTLIST);
	}

	// run the particle effect
	m_particle_effect->Render(context, m_num_active_particles, m_texture_srv, 
		world_matrix, view_matrix, projection_matrix);

	return true;
}


bool ParticleEmitter::Update(float delta_time) {
	static float t = 0.f;
	t += delta_time;

	float lt = 0.f;
	for (int i = 0; i < m_num_active_particles; i++) {
		lt = m_particle_lifetimes[i];

		if (m_particle_lifetimes[i] > 10000.f) {
			RemoveParticle(i);
			continue;
		}

		m_particle_positions[i].x = 0.25f * sin(m_particle_lifetimes[i] * 0.01f);
		m_particle_positions[i].y += delta_time * 0.001f;
		
		m_particle_lifetimes[i] += delta_time;
	}

	if (t > 100.f) {
		NewParticle();
		t = 0.f;
	}

	return true;
}


bool ParticleEmitter::InitialiseVertexBuffer(ID3D11Device* device) {

	D3D11_BUFFER_DESC vertex_buffer_desc;

	vertex_buffer_desc.Usage = D3D11_USAGE_DYNAMIC;
	vertex_buffer_desc.ByteWidth = sizeof(m_particle_positions[0]) * MAX_PARTICLES;
	vertex_buffer_desc.BindFlags = D3D11_BIND_VERTEX_BUFFER;
	vertex_buffer_desc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
	vertex_buffer_desc.MiscFlags = 0;
	vertex_buffer_desc.StructureByteStride = 0;

	D3D11_SUBRESOURCE_DATA vertex_data;

	vertex_data.pSysMem = m_particle_positions;
	vertex_data.SysMemPitch = 0;
	vertex_data.SysMemSlicePitch = 0;

	// Now create the vertex buffer.
	HRESULT result = device->CreateBuffer(&vertex_buffer_desc, &vertex_data, 
		&m_vertex_buffer);
	if (FAILED(result))	{
		return false;
	}

	return true;
}


bool ParticleEmitter::NewParticle() {
	if (m_num_active_particles >= MAX_PARTICLES) {
		return false;
	}

	// activate the first particle in the inactive set
	m_particle_positions[m_num_active_particles] = D3DXVECTOR3(0.f, 0.f, 0.f);
	m_particle_lifetimes[m_num_active_particles] = 0.f;

	m_num_active_particles++;

	return true;
}


bool ParticleEmitter::RemoveParticle(int index) {
	// copy the last member of the active set into this slot
	m_particle_positions[index] = m_particle_positions[m_num_active_particles - 1];
	m_particle_lifetimes[index] = m_particle_lifetimes[m_num_active_particles - 1];
	
	m_num_active_particles--;

	return true;
}