// Rachel Crawford (1204444@abertay.ac.uk) 2014

#ifndef TEXTURED_UNLIT_EFFECT_H_
#define TEXTURED_UNLIT_EFFECT_H_

#include "effect.h"

class TexturedUnlitEffect : public Effect {
public:
	
private:

};

#endif // TEXTURED_UNLIT_EFFECT_H_