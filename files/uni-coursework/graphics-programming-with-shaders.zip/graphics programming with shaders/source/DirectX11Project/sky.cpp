#include "sky.h"

#include <d3dx11tex.h>

#include <vector>

#include "d3dclass.h"
#include "helpers.h"
#include "cubemap_effect.h"



bool Sky::Initialise(D3DClass* direct3d, HWND hwnd) {
	// load cubemap
	HRESULT hr = D3DX11CreateShaderResourceViewFromFile(direct3d->GetDevice(),
		L"data/cubemap_2.dds", 0, 0, &m_cubemap_srv, 0);
	if FAILED(hr) {
		return false;
	}

	// set up cubemap shader pipeline
	m_cubemap_effect = new CubemapEffect;
	if (!m_cubemap_effect->Initialize(direct3d->GetDevice(), hwnd)){
		return false;
	}

	// generate the mesh (a sphere)
	{
		const int n_stacks = 10;
		const int n_slices = 10;

		const int vertex_count = n_stacks * n_slices;
		const int index_count = vertex_count * 6;
		m_index_count = index_count;

		//Vertex* vertices = new Vertex[vertex_count];
		//int*	indices  = new int[m_index_count];
		Vertex vertices[vertex_count];
		int indices[index_count];

		const float radius = 1.f;

		const float tau = 6.28318530718f;
		const float pi = tau / 2;
		
		const float vertical_theta = 1.f / (float)(n_stacks - 1);
		const float horizontal_theta = 1.f / (float)(n_slices - 1);
	
		int stack, slice;
		for (stack = 0; stack < n_stacks; stack++)
		{
			for (slice = 0; slice < n_slices; slice++)
			{
				float const y = sin(-(pi / 2) + pi * stack * vertical_theta);
				float const x = cos(tau * slice * horizontal_theta) * sin(pi * stack * vertical_theta);
				float const z = sin(tau * slice * horizontal_theta) * sin(pi * stack * vertical_theta);
				
				vertices[stack*n_stacks + slice].position = D3DXVECTOR3(x, y, z);
			}
		}

		// join the verts up such that they form an inside-out sphere
		// make a two-tri quad for each stack-slice
		for (stack = 0; stack < n_stacks; stack++)
		{
			for (slice = 0; slice < n_slices - 1; slice++)
			{
				int topLeftVertex = ((stack + 1)*n_stacks + slice);
				int botLeftVertex = ((stack)*n_stacks + slice);
				int botLeftIndex = botLeftVertex * 6;

				indices[botLeftIndex] = botLeftVertex;
				indices[botLeftIndex + 1] = topLeftVertex + 1;	// top right
				indices[botLeftIndex + 2] = topLeftVertex;		// top left

				indices[botLeftIndex + 3] = botLeftVertex;
				indices[botLeftIndex + 4] = botLeftVertex + 1;	// bottom right
				indices[botLeftIndex + 5] = topLeftVertex + 1;	// top right
			}
		}

		// vertices now contains all the vertices, indices now contains all the indices
		// turn them into buffers
		D3D11_BUFFER_DESC vertex_buffer_desc, index_buffer_desc;
		D3D11_SUBRESOURCE_DATA vertex_data, index_data;

		// Set up the description of the static vertex buffer.
		vertex_buffer_desc.Usage = D3D11_USAGE_DEFAULT;
		vertex_buffer_desc.ByteWidth = sizeof(Vertex) * vertex_count;
		vertex_buffer_desc.BindFlags = D3D11_BIND_VERTEX_BUFFER;
		vertex_buffer_desc.CPUAccessFlags = 0;
		vertex_buffer_desc.MiscFlags = 0;
		vertex_buffer_desc.StructureByteStride = 0;

		// Give the subresource structure a pointer to the vertex data.
		vertex_data.pSysMem = vertices;
		vertex_data.SysMemPitch = 0;
		vertex_data.SysMemSlicePitch = 0;

		// Now create the vertex buffer.
		HRESULT result = direct3d->GetDevice()->CreateBuffer(&vertex_buffer_desc, &vertex_data, 
			&m_vertex_buffer);
		if (FAILED(result))
		{
			return false;
		}

		// Set up the description of the static index buffer.
		index_buffer_desc.Usage = D3D11_USAGE_DEFAULT;
		index_buffer_desc.ByteWidth = sizeof(int) * index_count;
		index_buffer_desc.BindFlags = D3D11_BIND_INDEX_BUFFER;
		index_buffer_desc.CPUAccessFlags = 0;
		index_buffer_desc.MiscFlags = 0;
		index_buffer_desc.StructureByteStride = 0;

		// Give the subresource structure a pointer to the index data.
		index_data.pSysMem = &indices[0];
		index_data.SysMemPitch = 0;
		index_data.SysMemSlicePitch = 0;

		// Create the index buffer.
		result = direct3d->GetDevice()->CreateBuffer(&index_buffer_desc, &index_data, 
			&m_index_buffer);
		if (FAILED(result))
		{
			return false;
		}

		// free memory
		//delete[] vertices;
		//delete[] indices;
	}

	return true;
}


void Sky::Shutdown() {
	SafeRelease(&m_cubemap_srv);
	SafeRelease(&m_index_buffer);
	SafeRelease(&m_vertex_buffer);

	ShutdownObject(&m_cubemap_effect);
}


bool Sky::Render(D3DClass* direct3d, D3DXMATRIX world_matrix, D3DXMATRIX view_matrix,
	D3DXMATRIX projection_matrix) {
	// push verts and indices onto the gpu
	{
		unsigned int stride;
		unsigned int offset;

		// Set vertex buffer stride and offset.
		stride = sizeof(Vertex);
		offset = 0;

		// Set the vertex buffer to active in the input assembler so it can be rendered.
		direct3d->GetDeviceContext()->IASetVertexBuffers(0, 1, &m_vertex_buffer, &stride, &offset);

		// Set the index buffer to active in the input assembler so it can be rendered.
		direct3d->GetDeviceContext()->IASetIndexBuffer(m_index_buffer, DXGI_FORMAT_R32_UINT, 0);

		// Set the type of primitive that should be rendered from this vertex buffer, in this case triangles.
		direct3d->GetDeviceContext()->IASetPrimitiveTopology(
			D3D10_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
	}

	// use the sky effect to render them
	m_cubemap_effect->Render(direct3d->GetDeviceContext(), m_index_count, m_cubemap_srv,
		world_matrix, view_matrix, projection_matrix);

	return true;
}