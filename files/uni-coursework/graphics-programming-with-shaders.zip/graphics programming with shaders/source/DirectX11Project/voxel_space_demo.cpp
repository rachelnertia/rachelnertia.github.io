// Rachel Crawford (1204444@abertay.ac.uk) 2014

#include "voxel_space_demo.h"

#include "d3dclass.h"
#include "inputclass.h"


bool VoxelSpaceDemo::Initialize(D3DClass* direct3d, HWND hwnd) {
	if (!m_voxel_space_demo_effect.Initialize(direct3d->GetDevice(), hwnd)) {
		return false;
	}

	m_targetwindow.Initialize(direct3d->GetDevice(), 800, 600, 800, 600);

	m_camera.SetPosition(0.0f, 0.0f, -10.0f);

	return true;
}


bool VoxelSpaceDemo::Shutdown() {
	m_voxel_space_demo_effect.Shutdown();

	m_targetwindow.Shutdown();

	return true;
}


bool VoxelSpaceDemo::HandleInput(InputClass* input, float delta_time) {
	if (input->IsRightPressed()) {
		m_voxel_space_camera.angle_horizontal -= 0.1f;
	}
	if (input->IsLeftPressed()) {
		m_voxel_space_camera.angle_horizontal += 0.1f;
	}

	if (input->IsUpPressed()) {
		m_voxel_space_camera.x -= 2.0 * sin(m_voxel_space_camera.angle_horizontal);
		m_voxel_space_camera.y -= 2.0 * cos(m_voxel_space_camera.angle_horizontal);
	}
	if (input->IsDownPressed()) {
		m_voxel_space_camera.x += 2.0 * sin(m_voxel_space_camera.angle_horizontal);
		m_voxel_space_camera.y += 2.0 * cos(m_voxel_space_camera.angle_horizontal);
	}

	if (input->IsKeyPressed(DIK_A)) {
		m_voxel_space_camera.height += 2.0;
	}
	if (input->IsKeyPressed(DIK_Z)) {
		m_voxel_space_camera.height -= 2.0;
	}

	if (input->IsKeyPressed(DIK_PGUP)) {
		m_voxel_space_camera.angle_vertical -= 2.0f;
	}
	if (input->IsKeyPressed(DIK_PGDN)) {
		m_voxel_space_camera.angle_vertical += 2.0f;
	}

	m_voxel_space_demo_effect.SetCameraVariables(m_voxel_space_camera.angle_horizontal,
		m_voxel_space_camera.x, m_voxel_space_camera.y, m_voxel_space_camera.height,
		m_voxel_space_camera.angle_vertical);

	return true;
}


bool VoxelSpaceDemo::Render(D3DClass* direct3d) {
	D3DXMATRIX worldMatrix, viewMatrix, orthoMatrix;
	bool result;

	// Clear the buffers to begin the scene.
	direct3d->BeginScene(0.1f, 0.1f, 0.7f, 1.0f);

	// Generate the view matrix based on the camera's position.
	m_camera.Render();

	// Get the world, view, and ortho matrices from the camera and d3d objects.
	m_camera.GetBaseViewMatrix(viewMatrix);
	direct3d->GetWorldMatrix(worldMatrix);
	direct3d->GetOrthoMatrix(orthoMatrix);

	// Turn off the Z buffer to begin all 2D rendering.
	direct3d->TurnZBufferOff();

	// Put the target window vertex buffer on the graphics pipeline to prepare for drawing.
	m_targetwindow.Render(direct3d->GetDeviceContext());

	// do the big step - render onto the target window
	result = m_voxel_space_demo_effect.Render(direct3d->GetDeviceContext(),
		m_targetwindow.GetIndexCount(), NULL,
		worldMatrix, viewMatrix, orthoMatrix);
	if (!result) {
		return false;
	}

	// Turn the Z buffer back on now that all 2D rendering has completed.
	direct3d->TurnZBufferOn();

	// Present the rendered scene to the screen.
	direct3d->EndScene();

	return true;
}