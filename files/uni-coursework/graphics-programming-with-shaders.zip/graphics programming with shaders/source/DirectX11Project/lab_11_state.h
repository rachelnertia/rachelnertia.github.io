#ifndef LAB_11_STATE_H_
#define LAB_11_STATE_H_

#include "application_state.h"

class CameraClass;
class PlaneClass;
class ShadowShaderClass;
class MeshClass;
class RenderTextureClass;
class LightClass;
class DepthShaderClass;
class PositionClass;

// Shadows
class Lab11State : public ApplicationState {
public:
	Lab11State() {
		m_camera = NULL;
		m_plane = NULL;
		m_shadow_shader = NULL;
		m_mesh = NULL;
		m_render_texture = NULL;
		m_light = NULL;
	}

	bool Initialize(D3DClass* direct3d, HWND hwnd);
	bool Shutdown();
	bool HandleInput(InputClass* input, float delta_time);
	bool Render(D3DClass* direct3d);
private:
	static const int SHADOWMAP_WIDTH	= 1024;
	static const int SHADOWMAP_HEIGHT	= 1024;
	static const float SCREEN_NEAR;
	static const float SCREEN_DEPTH;

	bool RenderSceneToTexture(D3DClass* direct3d);

	CameraClass*		m_camera;
	PlaneClass*			m_plane;
	ShadowShaderClass*	m_shadow_shader;
	MeshClass*			m_mesh;
	RenderTextureClass*	m_render_texture;
	LightClass*			m_light;
	DepthShaderClass*	m_depth_shader;
	PositionClass*		m_position;

};

#endif // LAB_11_STATE_H_