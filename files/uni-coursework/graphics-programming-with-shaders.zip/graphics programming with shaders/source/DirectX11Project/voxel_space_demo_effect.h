// Rachel Crawford (1204444@abertay.ac.uk) 2014

#ifndef VOXEL_SPACE_DEMO_EFFECT_H_
#define VOXEL_SPACE_DEMO_EFFECT_H_

#include "effect.h"

// Uses a compute shader to demonstrate 'voxel space' rendering, a technique used in
// the Comanche games. (A similar technique was used in Outcast, I believe.) Polygons
// are more efficient, but this method has its charms, and the compute shaders beg 
// alternative rendering techniques to crawl out of the woodwork.
class VoxelSpaceDemoEffect : public Effect {
public:
	VoxelSpaceDemoEffect() 
		: m_compute_shader(NULL),
		  m_input_colormap_srv(NULL),
		  m_input_heightmap_srv(NULL),
		  m_output_texture_srv(NULL),
		  m_output_texture_uav(NULL),
		  m_camera_buffer(NULL),
		  m_camera_angle_horizontal(0.f),
		  m_camera_angle_vertical(0.f),
		  m_camera_position_x(0.f),
		  m_camera_position_y(0.f),
		  m_camera_height(0.f)
	{}

	bool Initialize(ID3D11Device* device, HWND hwnd);
	bool Shutdown();
	bool Render(ID3D11DeviceContext* context, int index_count,
		ID3D11ShaderResourceView* texture_srv,
		D3DXMATRIX world_matrix, D3DXMATRIX view_matrix,
		D3DXMATRIX projection_matrix);

	void SetCameraVariables(float angle_horizontal, float position_x, float position_y,
		float position_z, float angle_vertical);

private:
	struct CameraBuffer {
		float angle;
		D3DXVECTOR3 padding;
		D3DXVECTOR4 position;
	};

	ID3D11ComputeShader*		m_compute_shader;
	ID3D11ShaderResourceView*	m_input_colormap_srv;
	ID3D11ShaderResourceView*	m_input_heightmap_srv;
	ID3D11ShaderResourceView*	m_output_texture_srv;
	ID3D11UnorderedAccessView*	m_output_texture_uav;
	ID3D11Buffer*				m_camera_buffer;

	float m_camera_angle_horizontal;
	float m_camera_angle_vertical;
	float m_camera_position_x;
	float m_camera_position_y;
	float m_camera_height;
};

/*
	Future possibilities:

	Use another compute shader to run diffuse lighting calculations on the terrain, given a light direction
	and the heightmap and/or a normalmap, allowing dynamic generation of the shadowmap which currently
	is incorporated into the colormap.
*/

#endif // VOXEL_SPACE_DEMO_EFFECT_H_