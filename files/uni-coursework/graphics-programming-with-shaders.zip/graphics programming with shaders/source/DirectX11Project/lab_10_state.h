#ifndef LAB_10_STATE_H_
#define LAB_10_STATE_H_

#include "application_state.h"

class PositionClass;
class CameraClass;
class DepthShaderClass;
class PlaneClass;
class MeshClass;
class Effect;


class Lab10State : public ApplicationState {
public:
	Lab10State() {
		m_position = NULL;
		m_camera = NULL;
		m_depth_shader = NULL;
		m_plane = NULL;
		m_test_mesh = NULL;
		m_test_effect = NULL;
	}
	bool Initialize(D3DClass* direct3d, HWND hwnd);
	bool Shutdown();
	bool HandleInput(InputClass* input, float delta_time);
	bool Render(D3DClass* direct3d);
private:
	PositionClass*		m_position;
	CameraClass*		m_camera;
	DepthShaderClass*	m_depth_shader;
	PlaneClass*			m_plane;
	MeshClass*			m_test_mesh;
	Effect*				m_test_effect;
};

#endif // LAB_10_STATE_H_