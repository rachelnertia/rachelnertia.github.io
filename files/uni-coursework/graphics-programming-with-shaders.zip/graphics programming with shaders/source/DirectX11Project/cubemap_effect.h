// Rachel Crawford (1204444@abertay.ac.uk) 2014

#ifndef CUBEMAP_EFFECT_H_
#define CUBEMAP_EFFECT_H_

#include "effect.h"

class CubemapEffect : public Effect {
public:
	CubemapEffect() {

	}

	bool Initialize(ID3D11Device* device, HWND hwnd);

private:
	// defines a lightweight, position-only input type
	bool CreateVertexShaderInputLayout(ID3D11Device* device,
		ID3D10Blob* vs_bytecode);
};

#endif // CUBEMAP_EFFECT_H_