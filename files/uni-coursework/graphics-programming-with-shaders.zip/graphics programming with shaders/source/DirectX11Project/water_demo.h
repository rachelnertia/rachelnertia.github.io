// Rachel Crawford (1204444@abertay.ac.uk) 2014


#ifndef WATER_DEMO_H_
#define WATER_DEMO_H_

#include "application_state.h"

class CameraClass;
class PositionClass;
class PlaneClass;
class Sky;
class WaterEffect;
class TessellationPlane;
class LightClass;
class PixelateShader;
class RenderTextureClass;
class TargetWindowClass;


// Demonstrated per-frame vertex manipulation, dynamic tesselation, diffuse lighting, cube mapping
class WaterDemo : public ApplicationState {
public:
	WaterDemo() {
		m_position = NULL;
		m_camera = NULL;
		m_sky = NULL;
		m_water_plane = NULL;
		m_water_effect = NULL;
		m_water_tess_plane = NULL;
		m_directional_light = NULL;
		m_pixelate_shader = NULL;
		m_render_texture = NULL;
		m_targetwindow = NULL;
		m_elapsed_time = 0.f;
		m_tessellation_factor = 1.f;
		m_pixelation_threshold = 0.01f;
		m_pixelate = false;
		m_paused = false;
		m_wave_amplitude_modifier = 1.f;
	}

	bool Initialize(D3DClass* direct3d, HWND hwnd);
	bool Shutdown();
	bool HandleInput(InputClass* input, float delta_time);
	bool Render(D3DClass* direct3d);

private:
	bool RenderScene(D3DClass* direct3d);

	PositionClass*			m_position;
	CameraClass*			m_camera;

	Sky* m_sky;

	PlaneClass*	m_water_plane;
	WaterEffect* m_water_effect;
	TessellationPlane* m_water_tess_plane;

	LightClass* m_directional_light;

	PixelateShader* m_pixelate_shader;
	RenderTextureClass*	m_render_texture;
	TargetWindowClass* m_targetwindow;

	float m_elapsed_time;
	float m_tessellation_factor;

	float m_pixelation_threshold;

	bool m_pixelate;
	bool m_paused;

	float m_wave_amplitude_modifier;
};

#endif // WATER_DEMO_H_