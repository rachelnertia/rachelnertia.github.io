// Rachel Crawford (1204444@abertay.ac.uk) 2014

#ifndef PARTICLE_EFFECT_H_
#define PARTICLE_EFFECT_H_

#include "effect.h"

// Uses a geometry shader to perform point-sprite expansion. Input must consist only of
// a list of points, which don't have texture coordinates or normals, because they would
// serve no purpose.
class ParticleEffect : public Effect {
public:
	ParticleEffect() {
		m_geometry_shader = NULL;
	}

	bool Initialize(ID3D11Device* device, HWND hwnd);
	bool Shutdown();

	bool Render(ID3D11DeviceContext* context, int vertex_count,
		ID3D11ShaderResourceView* texture_srv,
		D3DXMATRIX world_matrix, D3DXMATRIX view_matrix,
		D3DXMATRIX projection_matrix);

private:
	bool CreateVertexShaderInputLayout(ID3D11Device* device,
		ID3D10Blob* vs_bytecode);
	bool CreateBlender(ID3D11Device* device);

	ID3D11GeometryShader* m_geometry_shader;
};

#endif // PARTICLE_EFFECT_H_