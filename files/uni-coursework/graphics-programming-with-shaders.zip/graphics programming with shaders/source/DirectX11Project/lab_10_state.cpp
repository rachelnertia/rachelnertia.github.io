#include "lab_10_state.h"

#include "positionclass.h"
#include "cameraclass.h"
#include "planeclass.h"
#include "meshclass.h"
#include "depthshaderclass.h"
#include "textured_unlit_effect.h"
#include "d3dclass.h"
#include "helpers.h"
#include "inputclass.h"


bool Lab10State::Initialize(D3DClass* direct3d, HWND hwnd) {
	m_position = new PositionClass;
	m_position->SetPosition(0.0f, 0.0f, -5.0f);

	m_camera = new CameraClass;
	m_camera->SetPosition(0.0f, 0.0f, -5.0f);

	m_depth_shader = new DepthShaderClass;
	if (!m_depth_shader->Initialize(direct3d->GetDevice(), hwnd)) {
		return false;
	}

	m_plane = new PlaneClass;
	if (!m_plane->Initialize(direct3d->GetDevice(), L"data/bumblebee.png")) {
		return false;
	}

	m_test_mesh = new MeshClass;
	if (!m_test_mesh->Initialize(direct3d->GetDevice(), L"data/bumblebee.png")) {
		return false;
	}

	m_test_effect = new TexturedUnlitEffect;
	if (!m_test_effect->Initialize(direct3d->GetDevice(), hwnd)) {
		return false;
	}

	return true;
}


bool Lab10State::Shutdown() {
	if (m_position) {
		delete m_position;
		m_position = NULL;
	}

	if (m_camera) {
		delete m_camera;
		m_camera = NULL;
	}

	ShutdownObject(&m_depth_shader);
	ShutdownObject(&m_plane);

	ShutdownObject(&m_test_mesh);
	ShutdownObject(&m_test_effect);

	return true;
}


bool Lab10State::HandleInput(InputClass* input, float delta_time) {
	bool keyDown;
	float posX, posY, posZ, rotX, rotY, rotZ;

	// Set the frame time for calculating the updated position.
	m_position->SetFrameTime(delta_time);

	keyDown = input->IsLeftPressed();
	m_position->TurnLeft(keyDown);

	keyDown = input->IsRightPressed();
	m_position->TurnRight(keyDown);

	keyDown = input->IsUpPressed();
	m_position->MoveForward(keyDown);

	keyDown = input->IsDownPressed();
	m_position->MoveBackward(keyDown);

	keyDown = input->IsAPressed();
	m_position->MoveUpward(keyDown);

	keyDown = input->IsZPressed();
	m_position->MoveDownward(keyDown);

	keyDown = input->IsPgUpPressed();
	m_position->LookUpward(keyDown);

	keyDown = input->IsPgDownPressed();
	m_position->LookDownward(keyDown);

	// Get the view point position/rotation.
	m_position->GetPosition(posX, posY, posZ);
	m_position->GetRotation(rotX, rotY, rotZ);

	// Set the position of the camera.
	m_camera->SetPosition(posX, posY, posZ);
	m_camera->SetRotation(rotX, rotY, rotZ);

	return true;
}


bool Lab10State::Render(D3DClass* direct3d) {
	bool result = true;

	D3DXMATRIX worldMatrix, viewMatrix, projectionMatrix;

	// Clear the buffers to begin the scene.
	direct3d->BeginScene(0.1f, 0.1f, 0.1f, 1.0f);

	// Generate the view matrix based on the camera's position.
	m_camera->Render();
	m_camera->GetViewMatrix(viewMatrix);

	// Get the world and projection matrices from the d3d object.
	direct3d->GetWorldMatrix(worldMatrix);
	direct3d->GetProjectionMatrix(projectionMatrix);

	m_test_mesh->Render(direct3d->GetDeviceContext());

	result = m_test_effect->Render(direct3d->GetDeviceContext(), m_test_mesh,
		worldMatrix, viewMatrix, projectionMatrix);
	if (!result) {
		return false;
	}

	m_plane->Render(direct3d->GetDeviceContext());

	result = m_depth_shader->Render(direct3d->GetDeviceContext(), m_plane->GetIndexCount(),
		worldMatrix, viewMatrix, projectionMatrix);
	if (!result) {
		return false;
	}

	// Present the rendered scene to the screen.
	direct3d->EndScene();

	return result;
}