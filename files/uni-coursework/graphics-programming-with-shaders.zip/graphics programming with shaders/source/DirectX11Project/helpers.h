// Rachel Crawford (1204444@abertay.ac.uk) 2014

#ifndef HELPERS_H_
#define HELPERS_H_

// Safely release a resource, provided it has a public 'Release' method.
template <class T> void SafeRelease(T **ppT)
{
	if (*ppT)
	{
		(*ppT)->Release();
		*ppT = NULL;
	}
}

// Safely shutdown an instance of a class that has a 'Shutdown' method.
template <class T> void ShutdownObject(T **ppT)
{
	if (*ppT)
	{
		(*ppT)->Shutdown();
		delete *ppT;
		*ppT = NULL;
	}
}


#endif // HELPERS_H_