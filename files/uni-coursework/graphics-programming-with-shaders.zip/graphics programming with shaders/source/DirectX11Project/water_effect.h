// Rachel Crawford (1204444@abertay.ac.uk) 2014

#ifndef WATER_EFFECT_H_
#define WATER_EFFECT_H_

#include "effect.h"

class LightClass;
class CameraClass;

// punt a flat surface onto the gpu and render it with this
class WaterEffect : public Effect {
public:
	WaterEffect() {
		m_hull_shader = NULL;
		m_domain_shader = NULL;
		m_tessellation_buffer = NULL;
		m_time_buffer = NULL;
		m_camera_buffer = NULL;
		m_sky_cubemap_srv = NULL;
		m_normalmap_srv = NULL;
	}
	bool Initialize(ID3D11Device* device, HWND hwnd);
	bool Shutdown();
	bool Render(ID3D11DeviceContext* context, int index_count,
		ID3D11ShaderResourceView* texture_srv,
		D3DXMATRIX world_matrix, D3DXMATRIX view_matrix,
		D3DXMATRIX projection_matrix, float time,
		float tessellation_factor, LightClass* light,
		CameraClass* camera, float wave_amplitude_modifier);
private:
	struct TessellationBuffer {
		float tessellation_factor;
		D3DXVECTOR3 padding;
	};

	struct TimeBuffer {
		float time;
		D3DXVECTOR3 padding0;
		float wave_amplitude_modifier;
		D3DXVECTOR3 padding1;
	};

	struct PixelShaderLightBuffer {
		D3DXVECTOR4 ambient_color;
		D3DXVECTOR4 diffuse_color;
		D3DXVECTOR4 specular_color;
		float specular_power;
		D3DXVECTOR3 padding;
		D3DXVECTOR4 light_direction;
	};

	struct CameraBuffer {
		D3DXVECTOR3 camera_position;
		float padding;
	};

	ID3D11HullShader* m_hull_shader;
	ID3D11DomainShader* m_domain_shader;

	ID3D11Buffer* m_tessellation_buffer;
	ID3D11Buffer* m_time_buffer;
	ID3D11Buffer* m_light_buffer;
	ID3D11Buffer* m_camera_buffer;

	ID3D11ShaderResourceView* m_sky_cubemap_srv;
	ID3D11ShaderResourceView* m_normalmap_srv;
};


#endif // WATER_EFFECT_H_