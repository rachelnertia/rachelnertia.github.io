// Rachel Crawford (1204444@abertay.ac.uk) 2014

#include "cubemap_effect.h"

bool CubemapEffect::Initialize(ID3D11Device* device, HWND hwnd) {
	// Create the pixel shader
	if (!CreateShaderObject(device, hwnd, L"cubemap_ps.hlsl", "main",
		(ID3D11DeviceChild**)&m_pixel_shader, ST_PIXEL)) {
		return false;
	}
	// Create the vertex shader
	if (!CreateShaderObject(device, hwnd, L"cubemap_vs.hlsl", "main",
		(ID3D11DeviceChild**)&m_vertex_shader, ST_VERTEX)) {
		return false;
	}

	if (!CreateMatrixBuffer(device)) {
		return false;
	}

	if (!CreateSampler(device)) {
		return false;
	}

	if (!CreateBlender(device)) {
		return false;
	}

	return true;
}


bool CubemapEffect::CreateVertexShaderInputLayout(ID3D11Device* device,
	ID3D10Blob* vs_bytecode) {
	D3D11_INPUT_ELEMENT_DESC polygonLayout[1];
	unsigned int numElements;

	// Create the vertex input layout description.
	// This setup needs to match the VertexType stucture in the MeshClass and
	// in the shader.
	polygonLayout[0].SemanticName = "POSITION";
	polygonLayout[0].SemanticIndex = 0;
	polygonLayout[0].Format = DXGI_FORMAT_R32G32B32_FLOAT;
	polygonLayout[0].InputSlot = 0;
	polygonLayout[0].AlignedByteOffset = 0;
	polygonLayout[0].InputSlotClass = D3D11_INPUT_PER_VERTEX_DATA;
	polygonLayout[0].InstanceDataStepRate = 0;

	// Get a count of the elements in the layout.
	numElements = sizeof(polygonLayout) / sizeof(polygonLayout[0]);

	// Create the vertex input layout.
	HRESULT result = device->CreateInputLayout(polygonLayout, numElements,
		vs_bytecode->GetBufferPointer(),
		vs_bytecode->GetBufferSize(), &m_layout);
	if (FAILED(result))
	{
		return false;
	}

	return true;
}