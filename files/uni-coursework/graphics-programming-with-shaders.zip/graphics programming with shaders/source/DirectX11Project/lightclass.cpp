#include "lightclass.h"


LightClass::LightClass()
{
	m_ambientColor = D3DXVECTOR4(0, 0, 0, 1);
	m_diffuseColor = D3DXVECTOR4(0, 0, 0, 1);
	m_direction = D3DXVECTOR4(0, 0, 0, 1);
	m_position = D3DXVECTOR4(0, 0, 0, 1);
	m_specularColor = D3DXVECTOR4(0, 0, 0, 1);
	m_specularPower = 30.f;
	m_type = LIGHTTYPE_DIRECTIONAL_AND_AMBIENT; // type doesn't do anything yet
}


LightClass::LightClass(const LightClass& other)
{
}


LightClass::~LightClass()
{
}

void LightClass::GenerateViewMatrix() {
	D3DXVECTOR3 up;
	D3DXVECTOR3 position3d = m_position;
	//m_lookAt = (D3DXVECTOR3)m_direction;

	// Setup the vector that points upwards.
	up.x = 0.0f;
	up.y = 1.0f;
	up.z = 0.0f;

	// Create the view matrix from the three vectors.
	D3DXMatrixLookAtLH(&m_view_matrix, &position3d, &m_lookat, &up);
}

void LightClass::GenerateProjectionMatrix(float screen_near, float screen_depth) {
	float fieldOfView, screenAspect;

	// Setup field of view and screen aspect for a square light source.
	fieldOfView = (float)D3DX_PI / 2.0f;
	screenAspect = 1.0f;

	// Create the projection matrix for the light.
	D3DXMatrixPerspectiveFovLH(&m_projection_matrix, fieldOfView, screenAspect, 
		screen_near, screen_depth);
}


// setters:
//

void LightClass::SetAmbientColor(float red, float green, float blue, float alpha)
{
	m_ambientColor = D3DXVECTOR4(red, green, blue, alpha);
	return;
}

void LightClass::SetDiffuseColor(float red, float green, float blue, float alpha)
{
	m_diffuseColor = D3DXVECTOR4(red, green, blue, alpha);
	return;
}

void LightClass::SetSpecularColor(float red, float green, float blue, float alpha)
{
	m_specularColor = D3DXVECTOR4(red, green, blue, alpha);
	return;
}

void LightClass::SetSpecularPower(float power)
{
	m_specularPower = power;
}

void LightClass::SetDirection(float x, float y, float z)
{
	m_direction = D3DXVECTOR4(x, y, z, 0);
	return;
}

void LightClass::SetPosition(float x, float y, float z)
{
	m_position = D3DXVECTOR4(x, y, z, 0);
	return;
}

// getters:
//

D3DXVECTOR4 LightClass::GetAmbientColor()
{
	return m_ambientColor;
}

D3DXVECTOR4 LightClass::GetDiffuseColor()
{
	return m_diffuseColor;
}

D3DXVECTOR4 LightClass::GetSpecularColor()
{
	return m_specularColor;
}

D3DXVECTOR4 LightClass::GetDirection()
{
	return m_direction;
}

D3DXVECTOR4 LightClass::GetPosition()
{
	return m_position;
}


float LightClass::GetSpecularPower()
{
	return m_specularPower;
}

void LightClass::GetViewMatrix(D3DXMATRIX& view_matrix) {
	view_matrix = m_view_matrix;
}

void LightClass::GetProjectionMatrix(D3DXMATRIX& projection_matrix) {
	projection_matrix = m_projection_matrix;
}