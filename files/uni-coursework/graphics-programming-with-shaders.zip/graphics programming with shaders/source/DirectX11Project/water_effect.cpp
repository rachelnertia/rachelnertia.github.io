#include "water_effect.h"
#include "helpers.h"
#include "lightclass.h"
#include "cameraclass.h"


bool WaterEffect::Initialize(ID3D11Device* device, HWND hwnd) {
	// Create the pixel shader
	if (!CreateShaderObject(device, hwnd, L"water_ps.hlsl", "main",
		(ID3D11DeviceChild**)&m_pixel_shader, ST_PIXEL)) {
		return false;
	}
	// Create the vertex shader
	if (!CreateShaderObject(device, hwnd, L"water_vs.hlsl", "main",
		(ID3D11DeviceChild**)&m_vertex_shader, ST_VERTEX)) {
		return false;
	}
	// hull shader
	if (!CreateShaderObject(device, hwnd, L"water_hs.hlsl", "main",
		(ID3D11DeviceChild**)&m_hull_shader, ST_HULL)) {
		return false;
	}
	// demesne shader
	if (!CreateShaderObject(device, hwnd, L"water_ds.hlsl", "main",
		(ID3D11DeviceChild**)&m_domain_shader, ST_DOMAIN)) {
		return false;
	}

	// load sky cubemap
	HRESULT hr = D3DX11CreateShaderResourceViewFromFile(device, L"data/cubemap_2.dds",
		0, 0, &m_sky_cubemap_srv, 0);
	if (FAILED(hr)) {
		return false;
	}

	// load water normalmap
	hr = D3DX11CreateShaderResourceViewFromFile(device, L"data/water_normalmap_2.png",
		0, 0, &m_normalmap_srv, 0);
	if (FAILED(hr)) {
		return false;
	}

	if (!CreateMatrixBuffer(device)) {
		return false;
	}

	if (!CreateSampler(device)) {
		return false;
	}

	if (!CreateBlender(device)) {
		return false;
	}

	// set up tessellation buffer in hull shader (defines tessellation amount)
	{
		// the description of the dynamic tessellation constant buffer that is in the hull shader.
		D3D11_BUFFER_DESC tessellation_buffer_desc;
		tessellation_buffer_desc.Usage = D3D11_USAGE_DYNAMIC;
		tessellation_buffer_desc.ByteWidth = sizeof(TessellationBuffer);
		tessellation_buffer_desc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
		tessellation_buffer_desc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
		tessellation_buffer_desc.MiscFlags = 0;
		tessellation_buffer_desc.StructureByteStride = 0;

		// Create the constant buffer pointer so we can access the hull shader constant buffer from within this class.
		HRESULT result = device->CreateBuffer(&tessellation_buffer_desc, NULL, &m_tessellation_buffer);
		if (FAILED(result))	{
			return false;
		}
	}

	// set up time buffer in domain shader
	{
		// the description of the dynamic tessellation constant buffer that is in the hull shader.
		D3D11_BUFFER_DESC time_buffer_desc;
		time_buffer_desc.Usage = D3D11_USAGE_DYNAMIC;
		time_buffer_desc.ByteWidth = sizeof(TimeBuffer);
		time_buffer_desc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
		time_buffer_desc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
		time_buffer_desc.MiscFlags = 0;
		time_buffer_desc.StructureByteStride = 0;

		// Create the constant buffer pointer so we can access the hull shader constant buffer from within this class.
		HRESULT result = device->CreateBuffer(&time_buffer_desc, NULL, &m_time_buffer);
		if (FAILED(result))	{
			return false;
		}
	}

	// camera buffer - domain shader
	{
		// the description of the dynamic tessellation constant buffer that is in the hull shader.
		D3D11_BUFFER_DESC camera_buffer_desc;
		camera_buffer_desc.Usage = D3D11_USAGE_DYNAMIC;
		camera_buffer_desc.ByteWidth = sizeof(CameraBuffer);
		camera_buffer_desc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
		camera_buffer_desc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
		camera_buffer_desc.MiscFlags = 0;
		camera_buffer_desc.StructureByteStride = 0;

		// Create the constant buffer pointer so we can access the hull shader constant buffer from within this class.
		HRESULT result = device->CreateBuffer(&camera_buffer_desc, NULL, &m_camera_buffer);
		if (FAILED(result))	{
			return false;
		}
	}

	// set up light buffer for use in pixel shader
	{
		// the description of the dynamic tessellation constant buffer that is in the hull shader.
		D3D11_BUFFER_DESC light_buffer_desc;
		light_buffer_desc.Usage = D3D11_USAGE_DYNAMIC;
		light_buffer_desc.ByteWidth = sizeof(PixelShaderLightBuffer);
		light_buffer_desc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
		light_buffer_desc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
		light_buffer_desc.MiscFlags = 0;
		light_buffer_desc.StructureByteStride = 0;

		// Create the constant buffer pointer so we can access the hull shader constant buffer from within this class.
		HRESULT result = device->CreateBuffer(&light_buffer_desc, NULL, &m_light_buffer);
		if (FAILED(result))	{
			return false;
		}
	}

	return true;
}


bool WaterEffect::Shutdown() {
	// Safely clean up member variables.
	SafeRelease(&m_hull_shader);
	SafeRelease(&m_domain_shader);
	SafeRelease(&m_tessellation_buffer);
	SafeRelease(&m_time_buffer);
	SafeRelease(&m_light_buffer);
	SafeRelease(&m_sky_cubemap_srv);
	SafeRelease(&m_normalmap_srv);

	return Effect::Shutdown();
}


bool WaterEffect::Render(ID3D11DeviceContext* context, int index_count,
	ID3D11ShaderResourceView* texture_srv,
	D3DXMATRIX world_matrix, D3DXMATRIX view_matrix,
	D3DXMATRIX projection_matrix, float time,
	float tessellation_factor, LightClass* light,
	CameraClass* camera, float wave_amplitude_modifier) {
	// Send the matrices to the DOMAIN shader (not vx shader)
	{
		// Transpose the matrices to prepare them for the shader.
		D3DXMatrixTranspose(&world_matrix, &world_matrix);
		D3DXMatrixTranspose(&view_matrix, &view_matrix);
		D3DXMatrixTranspose(&projection_matrix, &projection_matrix);

		D3D11_MAPPED_SUBRESOURCE mapped_resource;

		// Lock the constant buffer so it can be written to.
		HRESULT result = context->Map(m_matrix_buffer, 0,
			D3D11_MAP_WRITE_DISCARD, 0, &mapped_resource);
		if (FAILED(result))	{
			return false;
		}

		// Get a pointer to the data in the constant buffer.
		MatrixBuffer* matrix_buffer = (MatrixBuffer*)mapped_resource.pData;

		// Copy the matrices into the constant buffer.
		matrix_buffer->world = world_matrix;
		matrix_buffer->view = view_matrix;
		matrix_buffer->projection = projection_matrix;

		// Unlock the constant buffer.
		context->Unmap(m_matrix_buffer, 0);

		// Now set the constant buffer in the vertex shader with the updated 
		// values.
		context->DSSetConstantBuffers(0, 1, &m_matrix_buffer);
	}
	// send time buffer to domain shader
	{
		D3D11_MAPPED_SUBRESOURCE mapped_resource;

		HRESULT result = context->Map(m_time_buffer, 0,
			D3D11_MAP_WRITE_DISCARD, 0, &mapped_resource);
		if (FAILED(result))	{
			return false;
		}

		TimeBuffer* time_buffer = (TimeBuffer*)mapped_resource.pData;

		// copy data into buffer
		time_buffer->time = time;
		time_buffer->padding0 = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
		time_buffer->wave_amplitude_modifier = wave_amplitude_modifier;
		time_buffer->padding1 = D3DXVECTOR3(0.0f, 0.0f, 0.0f);

		context->Unmap(m_time_buffer, 0);

		context->DSSetConstantBuffers(1, 1, &m_time_buffer);
	}
	// send camera buffer to domain shader
	{
		D3D11_MAPPED_SUBRESOURCE mapped_resource;

		HRESULT result = context->Map(m_camera_buffer, 0,
			D3D11_MAP_WRITE_DISCARD, 0, &mapped_resource);
		if (FAILED(result))	{
			return false;
		}

		CameraBuffer* camera_buffer = (CameraBuffer*)mapped_resource.pData;

		// copy data into buffer
		camera_buffer->camera_position = camera->GetPosition();
		camera_buffer->padding = 0.f;

		context->Unmap(m_camera_buffer, 0);

		context->DSSetConstantBuffers(2, 1, &m_camera_buffer);
	}

	// send data to the hull shader, stored in TesselationBuffer
	{
		D3D11_MAPPED_SUBRESOURCE mapped_resource;

		// Lock the tessellation constant buffer so it can be written to.
		HRESULT result = context->Map(m_tessellation_buffer, 0, 
			D3D11_MAP_WRITE_DISCARD, 0, &mapped_resource);
		if (FAILED(result))	{
			return false;
		}

		// Get a pointer to the data in the tessellation constant buffer.
		TessellationBuffer* tesselation_buffer = (TessellationBuffer*)mapped_resource.pData;

		// Copy the tessellation data into the constant buffer.
		tesselation_buffer->tessellation_factor = tessellation_factor;
		tesselation_buffer->padding = D3DXVECTOR3(0.0f, 0.0f, 0.0f);

		// Unlock the tessellation constant buffer.
		context->Unmap(m_tessellation_buffer, 0);

		// Now set the tessellation constant buffer in the hull shader with the updated values.
		context->HSSetConstantBuffers(0, 1, &m_tessellation_buffer);

	}

	// send light data to the pixel shader, stored in LightBuffer
	{
		D3D11_MAPPED_SUBRESOURCE mapped_resource;

		// Lock the tessellation constant buffer so it can be written to.
		HRESULT result = context->Map(m_light_buffer, 0,
			D3D11_MAP_WRITE_DISCARD, 0, &mapped_resource);
		if (FAILED(result))	{
			return false;
		}

		// Get a pointer to the data in the tessellation constant buffer.
		PixelShaderLightBuffer* light_buffer = (PixelShaderLightBuffer*)mapped_resource.pData;

		// Copy the tessellation data into the constant buffer.
		light_buffer->ambient_color = light->GetAmbientColor();
		light_buffer->diffuse_color = light->GetDiffuseColor();
		light_buffer->light_direction = light->GetDirection();
		light_buffer->specular_color = light->GetSpecularColor();
		light_buffer->specular_power = light->GetSpecularPower();

		// Unlock the tessellation constant buffer.
		context->Unmap(m_light_buffer, 0);

		// Now set the tessellation constant buffer in the hull shader with the updated values.
		context->PSSetConstantBuffers(0, 1, &m_light_buffer);
	}

	// send normalmap to vertex shader
	context->DSSetShaderResources(0, 1, &m_normalmap_srv);
	// it'll need the sampler, too
	context->DSSetSamplers(0, 1, &m_sampler_state);

	// Send cubemap to pixel shader
	context->PSSetShaderResources(0, 1, &m_sky_cubemap_srv);

	// Set the vertex input layout.
	context->IASetInputLayout(m_layout);

	// Set the shaders that will be used to render
	context->VSSetShader(m_vertex_shader, NULL, 0);
	context->HSSetShader(m_hull_shader, NULL, 0);
	context->DSSetShader(m_domain_shader, NULL, 0);
	context->PSSetShader(m_pixel_shader, NULL, 0);

	// Set the sampler state in the pixel shader.
	context->PSSetSamplers(0, 1, &m_sampler_state);

	// set the blend state in the pixel shader
	context->OMSetBlendState(m_blend_state, 0, 0xffffffff);

	// Render the triangle.
	context->DrawIndexed(index_count, 0, 0);

	// clean up
	context->VSSetShader(NULL, NULL, 0);
	context->HSSetShader(NULL, NULL, 0);
	context->DSSetShader(NULL, NULL, 0);
	context->PSSetShader(NULL, NULL, 0);

	return true;
}